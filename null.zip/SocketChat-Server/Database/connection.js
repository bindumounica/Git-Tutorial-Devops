// Importing the AWS SDK
const AWS = require('aws-sdk');

// Configuration object for AWS SDK
const config = {
    apiVersion: '2023-05-05', // Specify the desired API version
    accessKeyId: 'AKIAS73BDJ2KTU4K2O4B' ,//process.env.ACCESS_KEY_ID, // Access Key ID obtained from environment variables
    secretAccessKey: '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', //process.env.SECRET_ACCESS_KEY, // Secret Access Key obtained from environment variables
    region: 'us-west-2' //rocess.env.REGION, // AWS region obtained from environment variables
};

// Function to establish a connection to DynamoDB
const DynamoDBConnection = () => {
    try {
        AWS.config.update(config); // Update the AWS SDK configuration
        console.log('config', config)
        const DB = new AWS.DynamoDB.DocumentClient(); // Create a new DynamoDB DocumentClient
        console.log('[INFO] connected To DynamoDB'); // Log a success message
        return DB; // Return the DynamoDB DocumentClient instance
    } catch (error) {
        console.log('[ERROR] in connecting To DynamoDB', error); // Log an error message if connection fails
    }
};

// Establish a DynamoDB connection using the provided configuration
const DynamoDB = DynamoDBConnection(config);

// Export the DynamoDB connection for use in other modules
module.exports = DynamoDB;
