const express = require('express');
const bodyParser = require('body-parser');
const dynamoDB = require('./Database/connection');
const serverless = require('serverless-http');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3004;

app.use(bodyParser.json());
app.use(cors());
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');
// Create a WebSocket server
const wss = new WebSocket.Server({ port: 3000 });
// console.log('wss', wss)
// Create a mapping of connection IDs to WebSocket connections
const connections = new Map();
// console.log('connections', connections)

// Generate a unique connection ID
function generateConnectionId() {
  // Generate a unique ID using your preferred method (e.g., UUID library)
  return uuidv4(); // Replace with your implementation
}

// When a new WebSocket connection is established
wss.on('connection', (socket, req) => {
  console.log('on connecting........', req.url);
  console.log('on connectiion........', socket);
  // Generate a unique connection ID for the client
  // Get the host and protocol information from the req object
  const protocol = req.headers['x-forwarded-proto'] || 'http';
  const host = req.headers['host'];

  // Construct the URL using the extracted host and protocol
  const fullUrl = `${protocol}://${host}${req.url}`;
  const url = new URL(fullUrl);
  const queryParams = url.searchParams;

  // Accessing individual query parameters
  const param1 = queryParams.get('sender');
  const param2 = queryParams.get('reciever');

  console.log('param1:', param1);
  console.log('param2:', param2);
  const connectionId = String(param1)+"#CONNECT#"+String(param2)// generateConnectionId();
  console.log('connected initail', connectionId)
  // Store the connection ID and associated WebSocket connection
  connections.set(connectionId, socket);

  // Handle incoming messages
  socket.on('message', (message) => {
    // Process the incoming message
    console.log('message',typeof JSON.parse(message.toString('utf8')))
    let data = JSON.parse(message.toString('utf8'));
    let reciever = data.recipient;
    let sender = data.sender;
    let targetConnectionId = String(reciever)+"#CONNECT#"+ String(sender)
    console.log('targetConnectionId', targetConnectionId)
    handleMessage(targetConnectionId, message);
  });

  // Handle connection close
  socket.on('close', () => {
    // Remove the connection ID and associated WebSocket connection
    connections.delete(connectionId);
  });
});

// When you want to send a message to a specific client
function sendMessageToClient(targetConnectionId, message) {
  // Retrieve the WebSocket connection based on the target connection ID
  const socket = connections.get(targetConnectionId);
  console.log('targetConnectionId', targetConnectionId);
  // console.log('connections', socket)
  // Check if the connection is still active
  if (socket) {
    // Send the message to the target client
    console.log('socketmessage', message.toString('utf8'))
    socket.send(message.toString('utf8'));
  }
}

// Example function to handle incoming messages
function handleMessage(connectionId, message) {
  console.log(`Received message from connection ${connectionId}: ${message}`);

  // Example: Echo the message back to the sender
  sendMessageToClient(connectionId, message);
}


// Create a new message
app.post('/messages', async (req, res) => {
  try {
    const { sender, recipient, message } = req.body;
    const createdAt = JSON.stringify(Date.now());
    console.log('request', req.body);
    // Sort sender and recipient alphabetically for consistent ordering
    const sortedEmails = [sender, recipient].sort();
    const pk = `${sortedEmails[0]}#${sortedEmails[1]}`;
    const sk = createdAt;

    const params = {
      TableName: 'chats',
      Item: {
        pk,
        sk,
        sender,
        recipient,
        message,
        createdAt
      }
    };

    await dynamoDB.put(params).promise();
    console.log('Message created successfully');
    res.status(201).json({ message: 'Message created successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }
});

// Fetch messages between sender and recipient
app.get('/messages', async (req, res) => {
  try {
    const { sender, recipient } = req.query;
    console.log('request', req.query);
    
    // Sort sender and recipient alphabetically for consistent ordering
    const sortedEmails = [sender, recipient].sort();
    const pk = `${sortedEmails[0]}#${sortedEmails[1]}`;

    const params = {
      TableName: 'chats',
      KeyConditionExpression: 'pk = :pk',
      ExpressionAttributeValues: {
        ':pk': pk,
      },
      ScanIndexForward: true, // Sort in descending order,
      ProjectionExpression : 'sender, recipient, createdAt, message'
    };

    const result = await dynamoDB.query(params).promise();
    console.log('Items fetched successfully');
    res.status(200).json(result.Items);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred' });
  }
});

module.exports.handler = serverless(app);