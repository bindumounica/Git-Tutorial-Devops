const DynamoDB = require('../Database/connection');
// console.log('Dynm', DynamoDB)


function queryDynamoDBTable(tableName, queryParams, callback) {
    const params = {
      TableName: tableName,
      KeyConditionExpression: queryParams.keyConditionExpression,
      ExpressionAttributeValues: queryParams.expressionAttributeValues
    };
  
    DynamoDB.query(params, (err, data) => {
      if (err) {
        // Handle error using callback
        callback(err, null);
      } else {
        // Successful query
        callback(null, data.Items);
      }
    });
  }
  
  const tableName = 'chats';
  const queryParams = {
    keyConditionExpression: 'pk = :value',
    expressionAttributeValues: {
      ':value': 'check'
    }
  };
  
  queryDynamoDBTable(tableName, queryParams, (err, items) => {
    if (err) {
      console.error('Error querying DynamoDB:', err);
    } else {
      console.log('Queried items:', items);
    }
  });