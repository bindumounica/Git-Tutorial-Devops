// // const { defineConfig } = require('@vue/cli-service' )
// // const path = require('path' )

// // module.exports = defineConfig({
// //   devServer: {
// //     port: 8080 ,
// //     host: 'localhost' ,
// //     https: false ,
// //     open: true ,
// //      allowedHosts: 'all'
// //   },
// //   transpileDependencies: true ,
// //  // Other webpack configuration 
// //   chainWebpack: (config) => {
// //      // This is to enable IP and domain name access for webpack-dev-server. (Deprecated, written into DevServer) 
// //     // config.devServer.disableHostCheck(true) 
// //   }
// // })
module.exports = {
  devServer: {
	      compress: true,

    allowedHosts: [
      'localhost',
      'immigpt.net',
      '.immigpt.net',
      '35.172.199.183',
      
    ],
  },
};
