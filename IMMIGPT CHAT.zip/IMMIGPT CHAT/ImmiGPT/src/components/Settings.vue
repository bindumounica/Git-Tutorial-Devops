<template>
    <div>
        <div>
            <v-dialog
            v-model="dialog"
            max-width="500px"
            >
                <template>
                    <v-card style="padding: 16px;">
                        <div style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;">
                            <div>
                                <span><b>Chat History & Training</b></span>
                            </div>
                            <div>
                                <v-switch
                                v-model="switch1"
                                color="#0b4374"
                                ></v-switch>
                            </div>
                        </div>
                        <p style="text-align: left;">
                            Save new chats to your history and allow them to be used to improve ImmiGPT via model training. Unsaved chats will be deleted from our systems.
                        </p>
                        <v-divider style="margin-bottom:8px;"></v-divider>
                        <div v-if="!deleteInProgress && !accountDeleted" @click="deleteAccount()" style="text-align: left;cursor: pointer;">
                            <span><b>Delete account</b></span>
                        </div>
                        <div v-if="deleteInProgress">
                            <i>Deleting account...</i>
                            <v-progress-circular
                                size="25"
                                indeterminate
                                color="primary"
                            ></v-progress-circular>
                        </div>

                        <div v-if="accountDeleted">
                            <i>Account deleted successfully! &nbsp;</i>
                            <v-icon color="primary">mdi-check-circle-outline</v-icon>
                        </div>
                    </v-card>
                </template>
            </v-dialog>
        </div>
        <Footer></Footer>
    </div>
</template>

<script>
    import axios from 'axios';
    export default {
        data(){
            return {
                dialog : true,
                switch1: true,
                deleteInProgress: false,
                accountDeleted: false,
                token:''
            }
        },
        mounted(){
            this.token = this.$cookies.get('token');
        },
        methods: {
            deleteAccount(){
                let headers = {
                    Authorization : 'Bearer '+ this.token
                }
                this.deleteInProgress = true;
                console.log('headers', headers);
                let gauth = this.$cookies.get('gauth');
                if (gauth) {
                    headers['Google-Auth'] = 'True'
                }
                axios.post('https://backend.immigpt.net/deleteAccount',{}, {headers: headers})
                .then((response)=>{
                    this.accountDeleted = true;
                    this.deleteInProgress = false
                    console.log('response', response)
                    this.$cookies.remove('token');
                    this.$cookies.remove('name')
                    this.$cookies.remove('email')
                    this.$cookies.remove('picture');
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    setTimeout(() => {
                        this.$router.push({
                            name: 'Home'
                        })
                    }, 3000);
                })
                .catch((error)=>{
                    console.log('error', error)
                    if (error?.response?.status == 401) {
                        this.$cookies.remove('token');
                        this.$cookies.remove('name')
                        this.$cookies.remove('email')
                        this.$cookies.remove('picture');
                        document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                        this.$router.push({
                            name: 'Home'
                        })
                    }
                })
            }
        }
    }
</script>

<style>
.loading-icon:after {
  content: "⏳"; /* Replace with your loading icon */
}

.tick-icon:after {
  content: "✓"; /* Replace with your tick icon */
}
</style>