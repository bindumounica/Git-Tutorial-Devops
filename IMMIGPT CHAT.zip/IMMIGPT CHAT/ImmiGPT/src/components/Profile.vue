<template>
    <div class="sideBarMain">
        <div class="SideHeading cursor">
            <div style="display: flex; flex-direction: row;" @click="CloseProfile()">
                <!-- <v-icon style="margin-right: 8px;">mdi-arrow-left</v-icon> -->
                <span> {{ name }}</span>
            </div>
        </div>
        <v-divider style="background-color: #fff"></v-divider>
        <div style="padding: 32px;">
            <v-avatar style="background-color: #FFF;" size="200">
                <img v-if="picture" :src="picture" />
                <span style="font-size:10rem; font-weight:600;" v-else>{{name.substring(0,1)}}</span>
            </v-avatar>
        </div>
        <div
            style="background-color: #FFF;display: flex;flex-direction: column;justify-content:center ;align-items: flex-start;border: 2px #0b4374 solid;border-radius: 8px;">
            <span style="padding:16px 32px 0px 32px;">Your Name</span>
            <div v-if="!editNameFlag" style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
                <span style="padding:16px 32px 16px 32px;font-weight: bold;">{{ name }}</span>
                <div style="margin-right: 20px;cursor: pointer;"  @click="editName()">
                    <v-icon>mdi-pencil</v-icon>
                </div>
            </div>
            <div v-if="editNameFlag" style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
                <v-text-field :disabled="editFieldDisable" hide-details solo dense outlined flat style="padding:16px 32px 16px 32px;" v-model="newName"></v-text-field>
                <div style="margin-right: 20px;cursor: pointer;" @click="saveName()">
                    <v-icon>mdi-check-circle-outline</v-icon>
                </div>
            </div>
        </div>
        <div
            style="background-color: #FFF;display: flex;flex-direction: column;justify-content:center ;align-items: flex-start;border: 2px #0b4374 solid;margin-top: 56px;border-radius: 8px;">
            <span style="padding:16px 32px 0px 32px;">Your Email</span>
            <div style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
                <span style="padding:16px 32px 16px 32px;font-weight: bold;">{{ email }}</span>
            </div>
        </div>
        <v-container v-if="!isGoogleAuthenticated" fluid>
            <v-row justify="center" style="padding: 0px;">
                <v-col cols="12" style="padding: 0px;">
                <v-card style="border: 2px #0b4374 solid;margin-top: 56px;border-radius: 8px;" @click="isCardExpanded = true">
                    <v-card-title>
                    <span style="font-size:medium">Change Password</span>
                    <v-spacer></v-spacer>
                    <v-btn v-if="isCardExpanded" icon @click.stop="closeCard">
                        <v-icon dark>mdi-close</v-icon>
                    </v-btn>
                    <v-btn v-else icon @click.stop="isCardExpanded = true">
                        <v-icon dark>mdi-chevron-down</v-icon>
                    </v-btn>
                    </v-card-title>
                    <v-expand-transition>
                    <v-card-text v-show="isCardExpanded">
                        <v-form ref="form" @submit.prevent="changePassword">
                        <v-text-field outlined v-model="oldPassword" :rules="passwordRules" label="Old Password" type="password"></v-text-field>
                        <v-text-field outlined v-model="newPassword" :rules="passwordRules" label="New Password" type="password"></v-text-field>
                        <v-text-field outlined v-model="confirmPassword" :rules="getConfirmPasswordRules" label="Confirm Password" type="password"></v-text-field>
                        <div v-if="isInCorrectPassword">
                            <span style="font-size: medium;color: red;">** Incorrect old password provided</span>
                        </div>
                        <v-btn :loading = "isChangeLoading" color="#0b4374" type="submit"><span style="text-transform: capitalize;color: #FFF;">Change</span></v-btn>
                        </v-form>
                    </v-card-text>
                    </v-expand-transition>
                </v-card>
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>
<script>
import axios from 'axios';
export default {
	data: () => ({
        isGoogleAuthenticated : false,
        isInCorrectPassword : false,
		name : '',
		email : '',
		picture: '',
        editNameFlag: false,
		editFieldDisable: false,
		newName: '',
        isCardExpanded: false,
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
        passwordRules: [
            value => !!value || 'Password is required',
            value => value && value.length >= 8 || 'Password must be at least 8 characters',
        ],
        isChangeLoading : false
	}),
    computed: {
        getConfirmPasswordRules() {
        return [
            value => !!value || 'Confirm Password is required',
            value => value === this.newPassword || 'Passwords do not match',
        ];
        },
    },
    mounted(){
		this.name = this.$cookies.get('name')
		console.log('this.name', this.name)
        this.email = this.$cookies.get('email')
        this.picture = this.$cookies.get('picture')
		console.log('this.picture', this.picture)
        let gauth = this.$cookies.get('gauth');
        if (gauth) {
            this.isGoogleAuthenticated = true;
        }
	},
    methods: {
        changePassword() {
            this.isChangeLoading = true;
            let headers = {
                Authorization : 'Bearer '+ this.$cookies.get('token')
            }
			let request = { 
                "oldPassword" : this.oldPassword, 
                "newPassword" : this.newPassword
            }
            console.log('headers', headers);
            console.log('request', request)
            axios.put('https://backend.immigpt.net/updatePassword',request, {headers: headers})
            .then((response)=>{
                this.oldPassword = '';
                this.newPassword = '';
                this.confirmPassword = '';
                this.$refs.form.resetValidation();
                this.closeCard();
                this.isChangeLoading = false;
            })
            .catch((error)=>{
                console.log('error', error)
                if (error?.response?.status == 403) {
                    this.isInCorrectPassword = true;
                    this.oldPassword = '';
                    this.newPassword = '';
                    this.confirmPassword = '';
                    this.$refs.form.resetValidation();
                    this.isChangeLoading = false;
                }
                else if (error?.response?.status == 401) {
                    this.$cookies.remove('token');
                    this.$cookies.remove('name')
                    this.$cookies.remove('email')
                    this.$cookies.remove('picture');
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    this.$router.push({
                        name: 'Home'
                    })
                }
            })
        },
        closeCard() {
            this.isCardExpanded = false;
            this.$refs.form.resetValidation();
        },
        editName(){
			this.editNameFlag = true;
			this.newName = this.name;
		},
		saveName(){
			let headers = {
                Authorization : 'Bearer '+ this.$cookies.get('token')
            }
			let request = {
				"email" : this.$cookies.get('email'),
				"username" : this.newName
			}
            console.log('headers in editName', headers)
			this.editFieldDisable = true;
            let gauth = this.$cookies.get('gauth');
            if (gauth) {
                headers['Google-Auth'] = 'True'
            }
            axios.post('https://backend.immigpt.net/updateUserProfile',request, {headers: headers})
            .then((response)=>{
                console.log('response', response)
				this.$cookies.set('name', this.newName);
				this.name = this.newName;
				this.editNameFlag = false;
				this.editFieldDisable = false;
				this.newName = ''
            })
            .catch((error)=>{
                console.log('error', error)
                if (error?.response?.status == 401) {
                    this.$cookies.remove('token');
                    this.$cookies.remove('name')
                    this.$cookies.remove('email')
                    this.$cookies.remove('picture');
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    this.$router.push({
                        name: 'Home'
                    })
                }
            })
		}
    }
}
</script>
<style scoped>
@media screen and (min-width: 767px) {
	.sideBarMain {
		height: 100vh;
		background-color: #0b4374;
		display: flex;
		flex-direction: column;
	}
    .SideHeading {
        padding: 12px 16px;
        color: #FFF;
        font-weight: 700;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }
}

@media screen and (max-width: 767px) {
	/* .sideBarMain {
		display: none;
	} */
    .SideHeading {
        padding: 12px 16px;
        /* color: #FFF; */
        font-weight: 700;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
    }
}

.cursor{
    cursor: pointer;;
}
.v-card__text {
  padding: 24px;
}
</style>