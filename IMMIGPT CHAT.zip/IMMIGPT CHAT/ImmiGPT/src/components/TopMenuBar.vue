<template>
    <v-tabs v-model="activeTab" color="primary" hide-slider fixed-tabs active-class="primary--text">
        <v-tab :class="{'custom-tab-class': true}" v-for="(tab, index) in tabs" :key="index">
            <span style="text-transform: capitalize;font-size: medium;font-weight: bold;">{{ tab.title }}</span>
        </v-tab>
    </v-tabs>
</template>
  
<script>
export default {
    name: "TopTabBar",
    data() {
        return {
            activeTab: 0,
            tabs: [
                { title: "Immi GPT", content: "This is the content for Tab 2." },
                { title: "Chats", content: "This is the content for Tab 3." },
                { title: "Groups", content: "This is the content for Tab 3." },
                { title: "Calls", content: "This is the content for Tab 3." },
            ],
        };
    },
};
</script>
  
<style scoped>
/* Add custom styles here */
.primary--text {
    background-color: #0b4374;
    color: #FFF !important;
    border: 1px #FFF solid;
    border-top-width: 0px;
    border-bottom-width: 0px;
    /* border-radius: 8px; */
    /* Change to desired background color */
}
.custom-tab-class {
  max-width: 400px; /* Set maximum width to desired value */
}
</style>