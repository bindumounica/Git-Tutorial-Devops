<template>
    <div style="display: flex;flex-direction: column;justify-content:center;align-items: center;">
        <div style=" width: 80%;display: flex;flex-direction: column;align-items: flex-start;justify-content: flex-start;padding: 16px 12px;" v-for="(questionItem,index) in questionAndAnswers" :key="index"> 
            <span style="text-align: left;"><b>Q{{ (index + 1)+'. '+ questionItem.question}}</b></span>
            <span style="text-align: left;">{{ questionItem.answer }}</span>
        </div>
    </div>
</template>
<script>
export default {
    props : ['questionAndAnswers']
}
</script>