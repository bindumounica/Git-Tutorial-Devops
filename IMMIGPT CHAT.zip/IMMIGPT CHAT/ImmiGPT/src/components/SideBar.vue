<template>
	<div>
		<div>
			<div v-if="!openProfileFlag" class="sideBarMain">
				<div class="SideHeading cursor">
						<div style="display: flex; flex-direction: row;"
							@click="openProfile()"
						>
							<v-avatar
							style="background-color: #FFF;margin-right: 8px;"
							size="24"
							>
								<img v-if="picture" :src="picture"/>
								<span style="font-size:1rem; font-weight:600;color: #000;" v-else>{{name.substring(0,1)}}</span>
							</v-avatar>
							<span style="text-transform:capitalize;">{{ name }}</span>
						</div>
						<div style="display:flex; flex-direction: row;align-items: center;">
							<div style="margin-right: 20px;">
								<v-menu offset-y bottom left min-width="200px">
									<template v-slot:activator="{ on, attrs }">
									<v-icon v-bind="attrs" v-on="on" style="color: #FFF;">mdi-dots-vertical</v-icon>
									</template>
									<v-list>
									<v-list-item :class="(item == 'Profile') ? 'hideProfile' : ''" v-for="(item, index) in options" :key="index" @click="handleItemClick(item)">
										<v-list-item-title>{{ item }}</v-list-item-title>
										<v-divider></v-divider>
									</v-list-item>
									</v-list>
								</v-menu>
							</div>
							<div @click="closeSidebarAction()" style="display: flex;border: 1px #FFF solid;padding: 4px;border-radius: 4px;cursor: pointer;">
								<svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg>
							</div>
						</div>
					</div>
				<v-divider style="background-color: #fff"></v-divider>
				<div style="display: flex;flex-direction: row;align-items: center;">
					<div style = "width:50%" :class="activegpt ? 'SideHeadingActiveCenter cursor' : 'SideHeadingCenter cursor'"
					@click="handleClickOne('ImmiGPT')"
					>
						<div style="display: flex; flex-direction: row;justify-content: center;align-items: center;"
						>
							<span style="text-transform:capitalize;">ImmiGPT</span>
						</div>
					</div>
					<v-divider style="background-color: #fff"></v-divider>
					<div style = "width:50%" :class="activechats ? 'SideHeadingActiveCenter cursor' : 'SideHeadingCenter cursor'"
					@click="handleClickOne('Chats')"
					>
						<div style="display: flex; flex-direction: row;justify-content: center;align-items: center;"
						>
							<span style="text-transform:capitalize;">Chats</span>
						</div>
					</div>
				</div>
				<v-divider style="background-color: #fff"></v-divider>
				<div v-if="activeTab == 'ImmiGPT'">
					<div class="SideHeading cursor"
					@click="newChat()"
					>
						<span>New Chat</span>
						<v-btn
						solo
						dense
						flat
						elevation="0"
						style="text-transform: capitalize;color:#FFF; height: 0px;"
						color=#0B4374>
							<v-icon>mdi-plus</v-icon>
						</v-btn>
					</div>
					<v-divider style="background-color: #fff"></v-divider>
					<div class="scrollable-div">
						<div v-for="duration,indexi in history" :key="indexi">
							<span v-if="duration.questions.length > 0" style="text-align: left;color: rgb(255, 255, 255);display: flex;padding:16px;font-size: 0.85rem;font-weight: bold;">{{duration.period}}</span>
							<div class="cursor" v-for="(question,i) in duration.questions" :key="refreshing">
								<div class="Questions" @click="makeActiveQuestion(indexi, i)" :class="duration.activeQuestionFlag[i] ? 'ActiveQuestions' : ''">
									<div class="SideHeading" @click="renderSession(question.sessionId)">
										<v-icon color="#FFF" style="padding:0px 4px 0px 0px">mdi-message-outline</v-icon>
										<span v-if="!duration.editSessionFlag[i]" class="ellipsis" style="text-align: left;font-weight: 400;">{{question.firstQuestion }}</span>
										<v-text-field @click.stop class="custom-text-field" v-else dense flat outlined hide-details v-model="newSession" color="#FFF" style="border-color: #FFF;"></v-text-field>
									</div>
									<div v-if="duration.activeQuestionFlag[i]">
										<div style="display: flex;" v-if="!duration.editSessionFlag[i] && !duration.deleteSessionFlag[i]">
											<v-icon color="#FFF" style="padding: 0px 0px 0px 4px;" @click="tryEdit(indexi, i)">mdi-pencil-outline</v-icon>
											<v-icon color="#FFF" style="padding: 0px 4px;" @click="duration.deleteSessionFlag[i] = true; refreshing += 1;">mdi-delete-outline</v-icon>
										</div>
										<div style="display: flex;align-items:center;" v-else>
											<v-icon color="#FFF" style="padding: 0px 4px 0px 4px;" @click="closeEditSession(indexi, i)">mdi-close</v-icon>
											<v-icon v-if="!actionhappening" color="#FFF" style="padding: 0px 4px;" @click="saveEditSession(indexi, i)">mdi-check</v-icon>
											<v-progress-circular
												v-else
												size="20"
												indeterminate
												color="#FFF"
												style="padding: 0px 4px;"
											></v-progress-circular>
										</div>
									</div>
								</div>
								<v-divider v-if="i != questions.length"></v-divider>
							</div>
						</div>
					</div>
					<!-- <v-divider style="background-color: #fff"></v-divider> -->
				</div>
				<div v-if="activeTab == 'ImmiGPT'" class="fixedDivWrap">
					<div class="fixBottom">
						<v-divider style="background-color: #fff"></v-divider>
						<div class="SideHeading cursor">
							<div 
							@click="clearAllChats()"
							style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
								<span>Clear all conversations</span>
								<v-icon style="margin-right:20px; color:#FFF">mdi-delete</v-icon>
							</div>
						</div>
						<!-- <div class="SideHeading cursor">
							<span>Get Help!</span>
						</div>
						<div class="SideHeading cursor">
							<span>Log Out</span>
						</div> -->
					</div>
				</div>
				<div v-if="activeTab == 'Chats'">
					<div class="SideHeading"
					>	
						<div style="width:60%">
							<v-text-field v-model="chatSearchValue" prepend-inner-icon="mdi-magnify" hide-details rounded flat dense solo placeholder="Search chats" @change="handleClickOne('Chats')"></v-text-field>
						</div>
						<v-avatar @click="addContacts()" class="cursor" size="40" color="#FFF">
							<v-icon color="#0b4374">mdi-plus</v-icon>
						</v-avatar>
						<v-avatar @click="acceptContacts()" class="cursor" size="40" color="#FFF">
							<v-icon color="#0b4374">mdi-account-multiple-plus</v-icon>
						</v-avatar>
					</div>
					<v-divider style="background-color: #fff"></v-divider>
					<div class="scrollable-div">
						<div class="cursor" v-for="(chat,i) in chatlist" :key="refreshing" @click="getChatMessages(chat)">
							<div style="display: flex;flex-direction: row;justify-content: flex-start;align-items: center;padding: 8px 16px;">
								<v-avatar style="margin-right: 12px;" size="40" color="#d0d5dd">
									<v-icon color="#FFF" size="40">mdi-account-circle</v-icon>
								</v-avatar>
								<span style="color: #FFF;">{{chat.userName}}</span>
							</div>
							<v-divider style="background-color: #fff"></v-divider>
						</div>
					</div>
				</div>
			</div>
			<div v-else class="sideBarMain">
				<div class="SideHeading cursor">
						<div style="display: flex; flex-direction: row;"
						@click="CloseProfile()"
						>
							<v-icon style="color: #FFF;margin-right: 8px;">mdi-arrow-left</v-icon>
							<span> {{ name }}</span>
						</div>
					</div>
				<v-divider style="background-color: #fff"></v-divider>
				<div style="padding: 32px;">
					<v-avatar
					style="background-color: #FFF;"
							size="200"
					>
					<img v-if="picture" :src="picture"/>
					<span style="font-size:10rem; font-weight:600;" v-else>{{name.substring(0,1)}}</span>
					</v-avatar>
				</div>
				<div style="background-color: #FFF;display: flex;flex-direction: column;justify-content:center ;align-items: flex-start;border: 1px #0b4374 solid;">
					<span style="padding:16px 32px 0px 32px;">Your Name</span>
					<div v-if="!editNameFlag" style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
						<span style="padding:16px 32px 16px 32px;font-weight: bold;">{{ name }}</span>
						<div style="margin-right: 20px;cursor: pointer;" @click="editName()">
							<v-icon>mdi-pencil</v-icon>
						</div>
					</div>
					<div v-if="editNameFlag" style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
						<!-- <span style="padding:16px 32px 16px 32px;font-weight: bold;">{{ name }}</span> -->
						<v-text-field :disabled="editFieldDisable" hide-details solo dense outlined flat style="padding:16px 32px 16px 32px;" v-model="newName"></v-text-field>
						<div style="margin-right: 20px;cursor: pointer;" @click="saveName()">
							<v-icon>mdi-check-circle-outline</v-icon>
						</div>
					</div>
				</div>
				<div style="background-color: #FFF;display: flex;flex-direction: column;justify-content:center ;align-items: flex-start;border: 1px #0b4374 solid;margin-top: 56px;">
					<span style="padding:16px 32px 0px 32px;">Your Email</span>
					<div style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;width: 100%;">
						<span style="padding:16px 32px 16px 32px;font-weight: bold;">{{ email }}</span>
					</div>
				</div>
				<v-container v-if="!isGoogleAuthenticated" fluid>
					<v-row justify="center" style="padding: 0px;">
						<v-col cols="12" style="padding: 0px;">
						<v-card style="border: 2px #0b4374 solid;margin-top: 56px;border-radius: 8px;" @click="isCardExpanded = true">
							<v-card-title>
							<span style="font-size:medium">Change Password</span>
							<v-spacer></v-spacer>
							<v-btn v-if="isCardExpanded" icon @click.stop="closeCard">
								<v-icon dark>mdi-close</v-icon>
							</v-btn>
							<v-btn v-else icon @click.stop="isCardExpanded = true">
								<v-icon dark>mdi-chevron-down</v-icon>
							</v-btn>
							</v-card-title>
							<v-expand-transition>
							<v-card-text v-show="isCardExpanded">
								<v-form ref="form" @submit.prevent="changePassword">
								<v-text-field dense outlined v-model="oldPassword" :rules="passwordRules" label="Old Password" type="password"></v-text-field>
								<v-text-field dense outlined v-model="newPassword" :rules="passwordRules" label="New Password" type="password"></v-text-field>
								<v-text-field dense outlined v-model="confirmPassword" :rules="getConfirmPasswordRules" label="Confirm Password" type="password"></v-text-field>
								<div v-if="isInCorrectPassword">
									<span style="font-size: medium;color: red;">** Incorrect old password provided</span>
								</div>
								<v-btn  :loading = "isChangeLoading" color="#0b4374" type="submit"><span style="text-transform: capitalize;color: #FFF;">Change</span></v-btn>
								</v-form>
							</v-card-text>
							</v-expand-transition>
						</v-card>
						</v-col>
					</v-row>
				</v-container>
			</div>
			<div class="sideBarMobile text-center">
				<!-- Hello -->
				<v-menu ref="menu" transition="scroll-x-transition" :open-on-click="openSidebarClick" :close-on-content-click="true" bottom offset-y open-on-hover min-width="100%">
					<template v-slot:activator="{ on, attrs }">
						<v-btn elevation="0" color="#0B4374" dark v-bind="attrs" v-on="on">
							<v-icon>mdi-menu</v-icon>
						</v-btn>
					</template>
					<v-card  >
							  <!-- Close Button  -->
							  <div class="closeButton" @click="closeSidebar">
								 <v-btn icon color="#0B4374">
								 <v-icon>mdi-close</v-icon>
								 </v-btn>
							  </div>
	
						<v-list v-if="items1 || items2 || questions">
							<v-list-item style="min-height: 0px !important;" v-for="(item, index) in items1" :key="index">
								<v-list-item-title>
									<div @click="handleClickOne(item)" :class="((activegpt && item == 'ImmiGPT') || (activechats && item == 'Chats')) ? 'SideHeadingActiveMobile cursor' : 'SideHeadingMobile cursor'">
										<v-btn 
										hide-details
										dense
										text style="
											text-transform: capitalize;
											display: flex;
											justify-content: flex-start;
											font-size: 17px;
											font-weight: 600;
											letter-spacing: 0rem;
											padding: 12px 6px;
											/* width: 100%; */
											box-shadow: unset;
											"
											:color = "((activegpt && item == 'ImmiGPT') || (activechats && item == 'Chats')) ? '#FFF' : ''"
											>
											{{ item }}
										</v-btn>
									</div>
									<v-divider></v-divider>
								</v-list-item-title>
							</v-list-item>
							<div v-if="activeTab == 'ImmiGPT'" class="scrollable-div-mobile">
								<v-list-item  v-for="duration,indexi in history" :key="indexi" style="display: flex;flex-direction: column;justify-content: center;align-items: flex-start;min-height: 0px !important;">
									<span v-if="duration.questions.length > 0" style="text-align: left;display: flex;padding:16px 0px;font-size: 0.85rem;font-weight: bold;">{{duration.period}}</span>
									<div class="cursor" v-for="(question,i) in duration.questions" :key="refreshing">
										<div @click="makeActiveQuestion(indexi, i)" :class="duration.activeQuestionFlag[i] ? 'ActiveQuestions' : ''">
											<v-list-item-title @click="renderSession(question.sessionId)" >
												<div style="display: flex;justify-content: space-between;align-items: center;">
													<div style="display: flex;flex-direction: row;align-items: center;">
														<v-icon :color="duration.activeQuestionFlag[i] ? '#FFF' : '#000'" style="padding-right: 4px;">mdi-message-outline</v-icon>
														<v-btn
														v-if="!duration.editSessionFlag[i]"
														hide-details text style="
															text-transform: capitalize;
															display: flex;
															justify-content: flex-start;
															font-size: 17px;
															cursor: pointer;
															/* font-weight: 600; */
															letter-spacing: 0rem;
															padding: 12px 6px;
															/* width: 100%; */
															box-shadow: unset;
															"
															:color="duration.activeQuestionFlag[i] ? '#FFF' : '#000'"
															>
															<span class="ellipsis">{{ question.firstQuestion }}</span>
														</v-btn>
														<v-text-field @click.stop v-else dense outlined flat hide-details v-model="newSession" style="border-color: #0b4374;color: #FFF;" color="#FFF"></v-text-field>
													</div>
													<div v-if="duration.activeQuestionFlag[i]">
														<div style="display: flex;" v-if="!duration.editSessionFlag[i] && !duration.deleteSessionFlag[i]">
															<v-icon color="#FFF" style="padding: 0px 0px 0px 4px;" @click="tryEdit(indexi, i)">mdi-pencil</v-icon>
															<v-icon color="#FFF" style="padding: 0px 4px;" @click="duration.deleteSessionFlag[i] = true; refreshing += 1;">mdi-delete-outline</v-icon>
														</div>
														<div v-else style="display: flex;padding: 0px 4px 0px 4px;">
															<v-icon color="#FFF" @click="closeEditSession(indexi, i)">mdi-close</v-icon>
															<v-icon v-if="!actionhappening" color="#FFF" @click="saveEditSession(indexi, i)">mdi-check</v-icon>
															<v-progress-circular
																v-else
																size="20"
																indeterminate
																:color="(activeQuestion == index) ? '#FFF' : '#000'"
															></v-progress-circular>
														</div>
													</div>
												</div>
												<v-divider></v-divider>
											</v-list-item-title>
										</div>
									</div>
								</v-list-item>
							</div>
							<v-list-item v-if="activeTab == 'ImmiGPT'" v-for="(item, index) in items2" :key="index">
								<v-list-item-title>
									<div>
										<v-btn hide-details text 
										@click="handleClickThree(item)"
										style="
											text-transform: capitalize;
											display: flex;
											justify-content: flex-start;
											font-size: 17px;
											font-weight: 600;
											letter-spacing: 0rem;
											padding: 12px 6px;
											/* width: 100%; */
											box-shadow: unset;
										"
										>
											{{ item }}
										</v-btn>
									</div>
									<v-divider v-if="index != items2.length-1"></v-divider>
								</v-list-item-title>
							</v-list-item>
						</v-list>
					</v-card>
				</v-menu>
				<div v-if="activeTab == 'Chats'">
					<div style="width:87%">
						<v-text-field hide-details dense flat rounded solo v-model="chatSearchValue" placeholder="Search chats"></v-text-field>
					</div>
				</div>
				<div style="margin-right:12px;" v-if="activeTab == 'Chats'" @click="addContacts()" >
					<v-avatar size="40" color="#FFF">
						<v-icon color="#0b4374">mdi-plus</v-icon>
					</v-avatar>
				</div>
				<div v-if="activeTab == 'Chats'">
					<v-avatar @click="acceptContacts()" class="cursor" size="40" color="#FFF">
						<v-icon color="#0b4374">mdi-account-multiple-plus</v-icon>
					</v-avatar>
				</div>
				<div style="margin-right:20px;">
					<v-menu offset-y bottom left min-width="200px">
						<template v-slot:activator="{ on, attrs }">
						<v-icon v-bind="attrs" v-on="on" style="color: #FFF;">mdi-dots-vertical</v-icon>
						</template>
						<v-list>
						<v-list-item v-for="(item, index) in options" :key="index" @click="handleItemClick(item)">
							<v-list-item-title >{{ item }}</v-list-item-title>
						</v-list-item>
						</v-list>
					</v-menu>
				</div>
			</div>
			<div>
				<v-dialog
					transition="dialog-bottom-transition"
					scrollable
					max-width="600"
					v-model="addContactFlag"
					style="min-height: 200px;"	
				>
					<v-card>
						<v-toolbar
							color="#0b4374"
							><v-text-field
							v-model="contactsearchValue"
							rounded
							solo flat dense
							hide-details
							block
							color="#FFF"
							placeholder="Search contacts"
							append-icon="mdi-magnify"
							@change="searchAllContacts()"
							>
							</v-text-field>
						</v-toolbar>
						<div style="min-height: 300px;overflow-y: scroll; display: flex;flex-direction:column; align-items:flex-start;justify-content: flex-start;">
							<div>
	
							</div>
							<div v-for="contact,index in searchedContacts" :key="contact.id" style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;padding: 8px 16px; width: 100%;">
								<div style="display: flex;flex-direction: row;justify-content: center;align-items: flex-start;">
									<v-avatar size="50" :color="colors[(index % 5)+1]">
										<span style="font-size:large;font-weight: 600;color: #FFF;">{{ contact.userName.substring(0,1) }}</span>
									</v-avatar>
									<div style="display: flex;flex-direction: column; align-items: flex-start;justify-content: center;margin-left: 8px;">
										<span style="font-size:large;font-weight: 550;color: #000000cb;" class="ellipsis">{{ contact.userName }}</span>
										<span style="font-size:small;color: darkgrey;" class="ellipsis">{{ contact.emailId }}</span>
									</div>
								</div>
								<div>
									<v-checkbox
										v-model="ex4"
										color="#0b4374"
										hide-details
										style="margin:0px; padding: 0px;"
										:value="contact.id"
									></v-checkbox>
								</div>
							</div>
						</div>
						<div style="margin:16px"
						@click="AddMember()"
						>
							<v-btn
							solo
							flat
							:disabled="ex4.length == 0"
							:loading="addMemberLoader"
							color="#0b4374"
							block
							>
							<span style="text-transform: capitalize;color: #FFF;">{{ addButtonText }}</span>
							</v-btn>
						</div>
					</v-card>
				</v-dialog>
			</div>
			<div>
				<v-dialog
					transition="dialog-bottom-transition"
					scrollable
					max-width="650"
					v-model="acceptContactFlag"
					style="min-height: 200px;"	
				>
					<v-card>
						<v-toolbar
							color="#0b4374"
							><v-text-field
							v-model="contactsearchValueTwo"
							rounded
							solo flat dense
							hide-details
							block
							color="#FFF"
							placeholder="Search contacts"
							append-icon="mdi-magnify"
							@change="searchAllContacts()"
							>
							</v-text-field>
						</v-toolbar>
						<div style="min-height: 300px;overflow-y: scroll; display: flex;flex-direction:column; align-items:flex-start;justify-content: flex-start;">
							<div>
	
							</div>
							<div v-for="contact,index in searchedContacts" :key="contact.id" style="display: flex;flex-direction: row;justify-content: space-between;align-items: center;padding: 8px 16px; width: 100%;">
								<div style="display: flex;flex-direction: row;justify-content: center;align-items: flex-start;">
									<v-avatar size="50" :color="colors[(index % 5)+1]">
										<span style="font-size:large;font-weight: 600;color: #FFF;">{{ contact.userName.substring(0,1) }}</span>
									</v-avatar>
									<div style="display: flex;flex-direction: column; align-items: flex-start;justify-content: center;margin-left: 8px;">
										<span style="font-size:large;font-weight: 550;color: #000000cb;" class="ellipsis">{{ contact.userName }}</span>
										<span style="font-size:small;color: darkgrey;" class="ellipsis">{{ contact.emailId }}</span>
									</div>
								</div>
								<div>
									<div class="AcceptDenyNoDesktop">
										<v-btn
										depressed
										dense
										color="#0b4374"
										style="margin-right: 12px;"
										>
											<span style="color: #FFF;text-transform: capitalize;">Accept&nbsp;</span>
											<v-icon size="20" color="#FFF">mdi-check</v-icon>
										</v-btn>
										<v-btn
										depressed
										dense
										>
											<span style="text-transform: capitalize;">Deny&nbsp;</span>
											<v-icon size="20">mdi-close</v-icon>
										</v-btn>
									</div>
									<div style="width: 40px;" class="AcceptDenyNoMobile">
										<v-icon size="20" color="#0b4374">mdi-check</v-icon>
										<v-icon size="20">mdi-close</v-icon>
										<!-- <v-btn
										depressed
										dense
										color="#0b4374"
										style="margin-right: 12px;"
										>
											<v-icon size="20" color="#FFF">mdi-check</v-icon>
										</v-btn>
										<v-btn
										depressed
										dense
										>
											<v-icon size="20">mdi-close</v-icon>
										</v-btn> -->
									</div>
								</div>
							</div>
						</div>
					</v-card>
				</v-dialog>
			</div>
		</div>
	</div>
</template>

<script>
import axios from 'axios';
export default {
	props:['questions'],
	data: () => ({
		items1: ["ImmiGPT", "Chats", "New Chat"],
		items2: [ "Clear all conversations"],
		options: ["Profile", "Settings", "Get Help!","FAQs", "Log Out"],
		openProfileFlag: false,
		name : '',
		email : '',
		picture: '',
		activegpt: true,
		activechats: false,
		activeProfile: false,
		activeSettings:false,
		activeGetHelp:false,
		activefaq: false,
		editNameFlag: false,
		editFieldDisable: false,
		newName: '',
		refreshing:10,
		editSessionFlag: [],
		deleteSessionFlag: [],
		chatlist: [],
		activeQuestion: 0,
		token: '',
		activeTab: 'ImmiGPT',
		ex4 : [],
		actionhappening: false,
		addContactFlag: false,
		contactsearchValueTwo: '',
		acceptContactFlag: false,
		contactsearchValue: '',
		chatSearchValue: '',
		contactSearchLoader: false,
		addMemberLoader: false,
		addButtonText : 'Add Member',
		colors:['#0091D5', '#EA6A47', '#A5D8DD', '#1C4E80','#202020','#7E909A' ],
		searchedContacts: [],
		isCardExpanded: false,
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
        passwordRules: [
            value => !!value || 'Password is required',
            value => value && value.length >= 8 || 'Password must be at least 8 characters',
        ],
		isGoogleAuthenticated : false,
        isInCorrectPassword : false,
		isChangeLoading: false,
		openSidebar: false,
		history : []
	}),
	computed: {
        getConfirmPasswordRules() {
        return [
            value => !!value || 'Confirm Password is required',
            value => value === this.newPassword || 'Passwords do not match',
        ];
        },
    },
	mounted(){
		this.token = this.$cookies.get('token');
		this.name = this.$cookies.get('name')
		console.log('this.name', this.name)
        this.email = this.$cookies.get('email')
        this.picture = this.$cookies.get('picture')
		console.log('this.picture', this.picture)
		let gauth = this.$cookies.get('gauth');
        if (gauth) {
            this.isGoogleAuthenticated = true;
        }
		console.log('this.$props.questions', this.questions)
		console.log('this.history', this.history)
	},
	watch:{
		questions: function(newQuestions) {
			this.history = [
			{
				period : 'Today',
				questions : this.$props.questions.today,
				editSessionFlag : Array(this.$props.questions.today.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.today.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.today.length).fill(false)
			},
			{
				period : 'Yesterday',
				questions : this.$props.questions.yesterday,
				editSessionFlag : Array(this.$props.questions.yesterday.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.yesterday.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.yesterday.length).fill(false)
			},
			{
				period : 'This Week',
				questions : this.$props.questions.thisWeek,
				editSessionFlag : Array(this.$props.questions.thisWeek.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.thisWeek.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.thisWeek.length).fill(false)
			},
			{
				period : 'Last Week',
				questions : this.$props.questions.lastWeek,
				editSessionFlag : Array(this.$props.questions.lastWeek.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.lastWeek.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.lastWeek.length).fill(false)
			},
			{
				period : 'This Month',
				questions : this.$props.questions.thisMonth,
				editSessionFlag : Array(this.$props.questions.thisMonth.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.thisMonth.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.thisMonth.length).fill(false)
			},
			{
				period : 'Last Month',
				questions : this.$props.questions.lastMonth,
				editSessionFlag : Array(this.$props.questions.lastMonth.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.lastMonth.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.lastMonth.length).fill(false)
			},
			{
				period : 'Previous',
				questions : this.$props.questions.previous,
				editSessionFlag : Array(this.$props.questions.previous.length).fill(false),
				deleteSessionFlag : Array(this.$props.questions.previous.length).fill(false),
				activeQuestionFlag: Array(this.$props.questions.previous.length).fill(false)
			},
		]
			// this.editSessionFlag = Array(this.$props.questions.length).fill(false);
			// console.log('this.editSessionFlag', this.editSessionFlag)
			// this.deleteSessionFlag = Array(this.$props.questions.length).fill(false);
			// console.log('this.deleteSessionFlag', this.deleteSessionFlag)
		},
	},
	methods : {
		changePassword() {
			this.isChangeLoading = true;
            console.log('Hello man')
            let headers = {
                Authorization : 'Bearer '+ this.$cookies.get('token')
            }
			let request = { 
                "oldPassword" : this.oldPassword, 
                "newPassword" : this.newPassword
            }
            console.log('headers', headers);
            console.log('request', request)
            axios.put('https://backend.immigpt.net/updatePassword',request, {headers: headers})
            .then((response)=>{
                this.oldPassword = '';
                this.newPassword = '';
                this.confirmPassword = '';
                this.$refs.form.resetValidation();
                this.closeCard();
				this.isChangeLoading = false;
            })
            .catch((error)=>{
                console.log('error', error)
                if (error?.response?.status == 403) {
                    this.isInCorrectPassword = true;
                    this.oldPassword = '';
                    this.newPassword = '';
                    this.confirmPassword = '';
					this.$refs.form.resetValidation();
					this.isChangeLoading = false;
                }
                else if (error?.response?.status == 401) {
                    this.$cookies.remove('token');
                    this.$cookies.remove('name')
                    this.$cookies.remove('email')
                    this.$cookies.remove('picture');
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    this.$router.push({
                        name: 'Home'
                    })
                }
            })
        },
        closeCard() {
            this.isCardExpanded = false;
            this.$refs.form.resetValidation();
        },
		makeActiveQuestion(index1, index2){
			for (let index = 0; index < this.history.length; index++) {
				const duration = this.history[index];
				duration.activeQuestionFlag = Array(duration.activeQuestionFlag.length).fill(false)
				duration.editSessionFlag = Array(duration.editSessionFlag.length).fill(false)
				duration.deleteSessionFlag = Array(duration.deleteSessionFlag.length).fill(false)
			}
			this.history[index1].activeQuestionFlag[index2] = true;
			this.re
			this.refreshing+=1; 
		},
		newChat(){
			this.$emit('newChat');
		},
		renderSession(sessionId, i){
			console.log('in sidebar')
			this.$emit('renderSession', sessionId);
		},
		closeEditSession(indexi,i){
			this.history[indexi].editSessionFlag[i] = false;
			this.history[indexi].deleteSessionFlag[i] = false;
			this.refreshing += 1;
		},
		closeSidebarAction(){
			this.$emit('closeSideBar')
		},
		searchAllContacts(){
			let headers = {
				Authorization: 'Bearer '+this.token
			}
			let gauth = this.$cookies.get('gauth');
			if (gauth) {
                headers['Google-Auth'] = 'True'
            }
			this.contactSearchLoader = true;
			axios.get('https://backend.immigpt.net/users/searchUsers?searchValue='+this.contactsearchValue+'&length=10', {headers : headers})
			.then((response)=>{
				console.log('response', response.data)
				this.searchedContacts = response.data.users;
				this.contactSearchLoader = false;
			})
			.catch((error)=>{
				console.log('error', error);
				this.contactSearchLoader = false;
			})
		},
		AddMember(){
			let headers = {
				Authorization: 'Bearer '+this.token
			}
			let gauth = this.$cookies.get('gauth');
			if (gauth) {
                headers['Google-Auth'] = 'True'
            }
			let params = {
				users: this.ex4
			}
			this.addMemberLoader = true;
			axios.post('https://backend.immigpt.net/users/addContact',params, {headers : headers})
			.then((response)=>{
				console.log('response', response.data)
				this.addButtonText = 'Added'
				this.addMemberLoader = false;
				this.ex4 = []
				setTimeout(() => {this.addButtonText = 'Add Member'}, 1000);
				this.addContactFlag = false;
				this.handleClickOne('Chats')
			})
			.catch((error)=>{
				console.log('error', error);
				this.addMemberLoader = false;
			})
		},
		addContacts(){
			this.addContactFlag = true;
		},
		acceptContacts(){
			this.acceptContactFlag = true;
		},
		saveEditSession(indexi, i){
			if (this.history[indexi].editSessionFlag[i] == true) {
				let question = this.history[indexi].questions[i];
				let headers = {
					Authorization: 'Bearer '+this.token
				}
				let params = {
					sessionName : this.newSession
				}
				this.actionhappening = true;
				this.refreshing += 1;
				let gauth = this.$cookies.get('gauth');
                if (gauth) {
                    headers['Google-Auth'] = 'True'
                }
				axios.post('https://backend.immigpt.net/session/saveUserSession?sessionId='+question.sessionId,params, {headers: headers})
				.then((response)=>{
					console.log('### check', response)
					this.history[indexi].questions[i].firstQuestion = this.newSession;
					this.history[indexi].editSessionFlag[i] = false;
					this.refreshing += 1;
					this.actionhappening = false;
				})
				.catch((error)=>{
					this.actionhappening = false
					console.log('error', error)
					if (error?.response?.status == 401) {
						this.$cookies.remove('token');
						this.$cookies.remove('name')
						this.$cookies.remove('email')
						this.$cookies.remove('picture');
						document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
						this.$router.push({
							name: 'Home'
						})
					}
				})
			}
			else if (this.history[indexi].deleteSessionFlag[i] == true) {
				let question = this.history[indexi].questions[i];
				let headers = {
					Authorization: 'Bearer '+this.token
				}
				this.actionhappening = true;
				this.refreshing += 1;
				let gauth = this.$cookies.get('gauth');
                if (gauth) {
                    headers['Google-Auth'] = 'True'
                }
				axios.delete('https://backend.immigpt.net/deleteUserSessions?sessionId='+question.sessionId, {headers: headers})
				.then((response)=>{
					this.actionhappening = false
					console.log('this.history[indexi]', this.history[indexi])
					this.history[indexi].questions.splice(i,1);
					this.history[indexi].deleteSessionFlag.splice(i,1);
					this.history[indexi].activeQuestionFlag.splice(i,1);
					this.history[indexi].editSessionFlag.splice(i,1);
					this.refreshing += 1;
					console.log('this.history[indexi]', this.history[indexi])
				})
				.catch((error)=>{
					this.actionhappening = false
					console.log('error', error)
					if (error?.response?.status == 401) {
						this.$cookies.remove('token');
						this.$cookies.remove('name')
						this.$cookies.remove('email')
						this.$cookies.remove('picture');
						document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
						this.$router.push({
							name: 'Home'
						})
					}
				})
			}
		},
		tryEdit(indexi, i){
			console.log('done')
			this.history[indexi].editSessionFlag[i] = true
			this.newSession = this.history[indexi].questions[i].firstQuestion;
			this.refreshing += 1;
			console.log('this.editSessionFlag', this.history[indexi].editSessionFlag)
		},
		chatsAction(){
			this.activechats = true;
			this.activegpt = false;
			this.activeSettings = false;
			this.activeGetHelp = false;
			this.activeProfile =false;
		},
		ImmiGPTAction(){
			this.activechats = false;
			this.activegpt = true;
			this.activeSettings = false;
			this.activeGetHelp = false;
			this.activeProfile =false;
		},
		handleItemClick(item) {
			if (item == 'Log Out') {
				this.$cookies.remove('token');
				this.$cookies.remove('name')
				this.$cookies.remove('email')
				this.$cookies.remove('picture');
				this.$cookies.remove('gauth');
				this.$cookies.remove('userid');
				document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
				this.$router.push({
					name: 'Home'
				})
			}
			else if(item == 'Settings'){
				this.activechats = false;
				this.activegpt = false;
				this.activeSettings = true;
				this.activeGetHelp = false;
				this.activeProfile =false;
				this.activefaq = false;
				console.log('@@@@@@@@@check in settings', item)
				this.$emit('openMenuItem', item)
			}
			else if(item == 'Get Help!'){
				this.activechats = false;
				this.activegpt = false;
				this.activeSettings = false;
				this.activeGetHelp = true;
				this.activefaq = false;
				this.activeProfile =false;
				this.$emit('openMenuItem', item)
			}
			else if(item == 'Profile') {
				this.activechats = false;
				this.activegpt = false;
				this.activeSettings = false;
				this.activeGetHelp = false;
				this.activefaq = false;
				this.activeProfile =true;
				this.$emit('openMenuItem', item)
			} else if (item == 'FAQs') {
				this.activechats = false;
				this.activegpt = false;
				this.activeSettings = false;
				this.activeGetHelp = false;
				this.activefaq = true;
				this.activeProfile =false;
				this.$emit('openMenuItem', item)
			}
		},
		handleClickOne(item){
			if (item == 'ImmiGPT') {
				this.activeTab = item;
				this.ImmiGPTAction();
				this.$emit('openMenuItem', item)
			}
			else if (item == 'Chats') {
				console.log('this.chatlist[0]', this.chatlist)
				// this.getChatMessages(this.chatlist[0]);
				this.activeTab = item;
				this.chatsAction();
				console.log('&&reached')
				this.$emit('openMenuItem', item);

				let headers = {
					Authorization: 'Bearer '+this.token
				}
				let gauth = this.$cookies.get('gauth');
				if (gauth) {
					headers['Google-Auth'] = 'True'
				}
				let url = 'https://backend.immigpt.net/users/myContacts?length=100'
				if (this.chatSearchValue.length > 0) {
					url = url+'&searchValue='+ this.chatSearchValue
				}
				
				axios.get(url, {headers : headers})
				.then((response)=>{
					console.log('responsesee', response.data)
					this.chatlist = response.data.users;
					this.getChatMessages(this.chatlist[0]);
				})
				.catch((error)=>{
					console.log('error', error);
				})
			}
			else if (item == 'New Chat') {
				this.newChat();
				this.$emit('openMenuItem', item)
			}
		},
		handleClickThree(item){
			if(item == 'Clear all conversations') {
				this.clearAllChats();
			}
		},
		openProfile(){
			this.openProfileFlag = true;
		},
		CloseProfile(){
			this.openProfileFlag = false;
		},
		clearAllChats(){
			this.$props.questions = [];
			this.$emit('clearQuestions')
		},
		getChatMessages(chat){
			this.$emit('getChatMessages', chat)
		},
		editName(){
			this.editNameFlag = true;
			this.newName = this.name;
		},
		openSidebarClick(){
			this.openSidebar = !this.openSidebar;
		},
	 	closeSidebar() {
          
		   this.$refs.menu.isActive = false;
           },
		saveName(){
			let headers = {
                Authorization : 'Bearer '+ this.$cookies.get('token')
            }
			let request = {
				"email" : this.$cookies.get('email'),
				"username" : this.newName
			}
            console.log('headers in editName', headers)
			this.editFieldDisable = true;
			let gauth = this.$cookies.get('gauth');
                if (gauth) {
                    headers['Google-Auth'] = 'True'
                }
            axios.post('https://backend.immigpt.net/updateUserProfile',request, {headers: headers})
            .then((response)=>{
                console.log('response', response)
				this.$cookies.set('name', this.newName);
				this.name = this.newName;
				this.editNameFlag = false;
				this.editFieldDisable = false;
				this.newName = ''
            })
            .catch((error)=>{
                console.log('error', error)
                if (error?.response?.status == 401) {
                    this.$cookies.remove('token');
                    this.$cookies.remove('name')
                    this.$cookies.remove('email')
                    this.$cookies.remove('picture');
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    this.$router.push({
                        name: 'Home'
                    })
                }
            })
		}
	}
};
</script>
<style scoped>
@media screen and (min-width: 767px) {
	.sideBarMain {
		height: 100vh;
		background-color: #0b4374;
		display: flex;
		flex-direction: column;
		border-radius: 12px;
	}

	.sideBarMobile {
		display: none;
	}
	.ellipses{
		white-space: nowrap; 
		max-width: 0px; 
		overflow: hidden;
		text-overflow: ellipsis;
	}
	.hideProfile{
		display: none;
	}
	.ellipsis {
		white-space: nowrap; /* Prevents text from wrapping */
		overflow: hidden; /* Hides any overflowing text */
		text-overflow: ellipsis; /* Displays ellipses (...) for overflow */
		 max-width: 200px; /*Optional: Set a maximum width for the container*/
	}
	.ActiveQuestions{
		display: flex;justify-content: space-between;align-items: center;background-color: #336a99
	}
	.cursor{
		cursor: pointer;
	}
	.AcceptDenyNoMobile{
		display: none;
	}
}

@media screen and (max-width: 767px) {
	.sideBarMain {
		display: none;
	}

	.sideBarMobile {
		/* display: block; */
		background-color: #0b4374;
		color: #fff;
		height: 8vh;
		width: 100%;
		background-color: #0b4374;
		/* padding: 12px 0% 0% 0%;  */
		display: flex; 
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
	}
	.cursor{
		cursor: pointer;
		width: 100%;
	}
 	.closeButton {
       position: relative;
	   left: 43%;
       z-index: 1;
	   padding: 5px;
	   
    }
	.ellipses{
		white-space: nowrap; /* Prevents text from wrapping */
		overflow: hidden; /* Hides any overflowing text */
		text-overflow: ellipsis; /* Displays ellipses (...) for overflow */
		max-width: 270px;
	}
	.ellipsis {
		white-space: nowrap; /* Prevents text from wrapping */
		overflow: hidden; /* Hides any overflowing text */
		text-overflow: ellipsis; /* Displays ellipses (...) for overflow */
		max-width: 230px;; /* Optional: Set a maximum width for the container */
	}
	.ActiveQuestions{
		display: flex;justify-content: space-between;align-items: center;background-color: #336a99;
		border-radius: 8px;
		padding: 4px;
	}
	.AcceptDenyNoDesktop{
		display: none;
	}
}
.Questions{
	display: flex;justify-content: space-between;align-items: center;
}
.Questions:hover{
	display: flex;justify-content: space-between;align-items: center;background-color: #336a99
}
.SideHeading {
	padding: 12px 16px;
    color: #FFF;
    font-weight: 700;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
}
.SideHeadingCenter {
	padding: 12px 16px;
    color: #FFF;
    font-weight: 700;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
}
.SideHeadingActive {
	padding: 12px 16px;
    color: #0b4374;
    font-weight: 700;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
	background-color: #fff;
	border: 1px #0b4374 solid;
	border-radius: 8px;
}
.SideHeadingActiveCenter {
	padding: 12px 16px;
    color: #0b4374;
    font-weight: 700;
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
	background-color: #fff;
	border: 1px #0b4374 solid;
	border-radius: 8px;
}
.SideHeadingActiveMobile {
	padding: 12px 8px;
	margin-bottom: 6px;
    color: #FFF;
    font-weight: 700;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
	background-color: #0b4374;
	border-radius: 8px;
}
.SideHeadingMobile {
	/* padding: 12px 16px; */
    color: #FFF;
    font-weight: 700;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
}
.fixBottom {
	/* position: fixed; */
	bottom: 0;
	/* width: 20%; */
}

.fixedDivWrap {
	display: flex;
	flex-direction: column;
	justify-content: flex-end;
	flex: 1;
}

.scrollable-div {
  max-height: calc(100vh - 200px); /* 200px is the height of the component below */
  overflow-y: scroll;
  overflow-x:hidden;
}

.scrollable-div-mobile {
  max-height: calc(100vh - 240px); /* 200px is the height of the component below */
  overflow-y: scroll;
}
</style>

<style scoped>
.custom-text-field /deep/ .v-text-field__slot input {
  /* Override the input color */
  color: #FFF;
}

.custom-text-field /deep/ .v-input__control {
  /* Override the border color */
  border-color: #FFF !important;
}
.scrollable-div ::-webkit-scrollbar {
  width: 6px;
}

/* Track */
.scrollable-div ::-webkit-scrollbar-track {
  box-shadow: inset 0 0 5px #0b4374; 
  border-radius: 10px;
}
 
/* Handle */
.scrollable-div ::-webkit-scrollbar-thumb {
  background: #FFF; 
  border-radius: 10px;
}

/* Handle on hover */
.scrollable-div ::-webkit-scrollbar-thumb:hover {
  background: #FFF; 
}
</style>
