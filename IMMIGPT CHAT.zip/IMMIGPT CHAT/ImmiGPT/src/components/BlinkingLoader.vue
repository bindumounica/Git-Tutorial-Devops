<template>
    <div class="blinking-loader">
      <div class="dot dot1"></div>
      <div class="dot dot2"></div>
      <div class="dot dot3"></div>
    </div>
  </template>
  
  <style>
  .blinking-loader {
    display: flex;
    justify-content: flex-start;
    align-items: center;
    height: 100%;
    width: 100%;
  }
  
  .dot {
    height: 10px;
    width: 10px;
    background-color: #000;
    border-radius: 50%;
    margin: 0 5px;
    opacity: 0;
    animation: blink 0.8s infinite;
  }
  
  .dot1 {
    animation-delay: 0s;
  }
  
  .dot2 {
    animation-delay: 0.2s;
  }
  
  .dot3 {
    animation-delay: 0.4s;
  }
  
  @keyframes blink {
    0% {
      opacity: 0;
    }
    50% {
      opacity: 1;
    }
    100% {
      opacity: 0;
    }
  }
  </style>