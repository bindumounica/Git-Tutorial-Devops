<template>
    <!-- <div>
        <v-dialog
      v-model="dialog"
      persistent
      max-width="290"
    >
      <v-card style="display: flex;flex-direction: column; justify-content: center;align-items: center;">
        <v-card-text style="margin-top: 10%;font-size: large;color: #000;">This feature is coming soon</v-card-text>
        <v-card-actions >
          <v-spacer></v-spacer>
          <v-btn
            flat solo
            color="primary"
            @click="routeToHome()"
            >
            Home
            </v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    </div> -->
    <div>
        <div class="NoMobile chatMain" :key="refreshing">
            <div v-if="chatId">
                <div @click="openProfile()" style="display: flex;flex-direction: row;justify-content: flex-start;align-items: center;padding: 6px 16px;background-color: #f0f2f5;cursor: pointer;">
                    <v-avatar style="margin-right: 12px;" size="40" color="#d0d5dd">
                        <v-icon color="#FFF" size="40">mdi-account-circle</v-icon>
                    </v-avatar>
                    <span style="color: #000;">{{ chatName }}</span>
                </div>
            </div>
            <DesktopConversation :chat-id="chatId" />
            <!-- <div v-if="chatId" style="padding:32px;">
                <div v-if="messages.length == 0" class="flexCol alignCenter chatMain">
                    <v-icon size="200">mdi-message-text-outline</v-icon>
                    <span>No Messages</span>
                </div>
                <div  v-if="messages.length > 0" style="overflow-y: scroll;height: 530px;">
                    <div style="overflow-y: scroll;">
                        <div :class="messages.length > 0 ? 'chat-container': 'displaynone'">
                            <div v-for="(val, index) in messages" :key="index" :class="[val.sender === userId ? 'message sent' : 'message received']">
                                <div class="message-content">{{ val.message}}</div>
                                <b>{{ val.sender }}</b>: <em>{{ val.message }}</em>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <v-text-field hide-details placeholder="Send a message" v-model="text" append-icon="mdi-send" dense solo flat outlined rounded @keyup.enter="sendMessage()"></v-text-field>
                </div>
            </div> -->
            <!-- <div v-else>
                <div class="scrollable-div">
                    <div class="cursor" v-for="(chat,i) in chatlist" :key="refreshing" @click="getChatMessages(chat)">
                        <div style="display: flex;flex-direction: row;justify-content: flex-start;align-items: center;padding: 12px 16px;">
                            <v-avatar style="margin-right: 12px;" size="40" color="#d0d5dd">
                                <v-icon color="#FFF" size="40">mdi-account-circle</v-icon>
                            </v-avatar>
                            <span style="color: #000;">{{chat}}</span>
                        </div>
                        <v-divider style="background-color: #fff"></v-divider>
                    </div>
                </div>
            </div> -->
            <div>
                <v-navigation-drawer
                    v-model="drawer"
                    absolute
                    temporary
                    right
                    width="400"
                    >
                    <div style="background-color: #f0f2f5;display: flex;justify-content: flex-start;padding: 14px 16px;">
                        <span>Profile</span>
                    </div>
                    <v-divider></v-divider>
                    <Profile />
                </v-navigation-drawer>
            </div>
        </div>
        <div class="NoDesktop">
            <div class="scrollable-div">
                <div class="cursor" v-for="(chat,i) in chatlist" :key="refreshing" @click="getChatMessagesMobile(chat)">
                    <div style="display: flex;flex-direction: row;justify-content: flex-start;align-items: center;padding: 12px 16px;">
                        <v-avatar style="margin-right: 12px;" size="40" color="#d0d5dd">
                            <v-icon color="#FFF" size="40">mdi-account-circle</v-icon>
                        </v-avatar>
                        <span style="color: #000;">{{chat.userName}}</span>
                    </div>
                    <v-divider style="background-color: #fff"></v-divider>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios';
import Profile from './Profile.vue'
import DesktopConversation from '../views/DesktopConversation.vue'
export default {
    name: "App",
    components: {
        Profile,
        DesktopConversation
    },
    data: () => ({
        dialog : true,
        chatId: null,
        drawer: null,
        chatName: '',
        token: '',
        text : '',
        userId: '',
        receipentId : '',
        messages: [],
        chatlist: ["Yeswanth Ravipati"],
        socket: null
    }),
    created() {
    // Create the WebSocket instance
        this.socket = new WebSocket('ws://localhost:3000');

        // Define a WebSocket 'onmessage' event handler to receive messages from the server
        this.socket.onmessage = (event) => {
            const message = JSON.parse(event.data);
            console.log('messageme', message)
            // Check if the message is intended for the current user
            console.log('checkme', message.recipient === this.userId, message.recipient , this.userId)
            if (message.recipient === this.userId || message.sender === this.userId) {
                this.messages.push(message);
            }
        };
    },
    mounted(){
        this.token = this.$cookies.get('token')
        let headers = {
				Authorization: 'Bearer '+this.token
            }
            let gauth = this.$cookies.get('gauth');
            if (gauth) {
                headers['Google-Auth'] = 'True'
            }
            let url = 'https://backend.immigpt.net/users/myContacts?length=100'
            // if (this.chatSearchValue.length > 0) {
            //     url = url+'&searchValue='+ this.chatSearchValue
            // }
            
            axios.get(url, {headers : headers})
            .then((response)=>{
                console.log('response', response.data)
                this.chatlist = response.data.users;
                this.refreshing += 1;
            })
            .catch((error)=>{
                console.log('error', error);
            })
    },
    methods: {
        routeToHome(){
            this.dialog = false;
            this.$router.push({ name : 'Home'})
        },
        getChatMessages(chat){
            console.log('&&&reached', chat);
            this.chatId = chat.emailId;
            this.chatName= chat.userName;
            this.receipentId = this.chatId;
            this.userId = this.$cookies.get('userId');
            this.refreshing += 1;
            if (this.userId) {
                // this.socket.send(JSON.stringify({ event: 'join', userId: this.userId }));
            }
        },
        getChatMessagesMobile(chat){
            console.log('chat', chat)
            this.$router.push({
                path: '/chat/'+chat.emailId+'-'+chat.userName
            })
        },
        openProfile(){
            this.drawer = true;
        },
        handleBackPress(event) {
            if (event.keyCode === 27) { // Check if the key code is for the "Escape" key
                // Perform your desired action when the backpress event occurs
                this.chatId = null;
                console.log('logged back event');
            }
        },
    }
}
</script>
<style scoped>
@media screen and (max-width: 767px) {
    .chatMain{
        height: 92vh;
    }
    .NoMobile{
        display: none;
    }
}
@media screen and (min-width: 768px) {
    .chatMain{
        height: calc(100vh - 156px);
        /* background-color: #FFF; */
    }
    .chat-container {
        display: flex;
        flex-direction: column;
        height: 77vh;
        /* align-items: center; */
        justify-content: flex-end;
        overflow-y: scroll; 
    }

    .NoDesktop{
        display: none !important;
    }

    .message-list {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    }

    .message {
    display: flex;
    flex-direction: column;
    max-width: 70%;
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 8px;
    word-wrap: break-word;
    }

    .message-content {
    word-wrap: break-word;
    text-align: left;
    }

    .sent {
    align-self: flex-end !important;
    background-color: #0B4374;
    color: #FFF;
    }

    .received {
    align-self: flex-start !important;
    background-color: #f0f2f5;
    color: #000;
    }
}

.flexCol{
    display: flex;
    flex-direction: column;
}
.alignCenter{
    justify-content: center;
    align-items: center;
}
.displaynone{
    display: none;
}
</style>