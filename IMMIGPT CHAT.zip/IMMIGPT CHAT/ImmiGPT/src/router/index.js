import Vue from 'vue'
import VueRouter from 'vue-router'


Vue.use(VueRouter)

const routes = [
    {
		path: '/',
		name: 'Home',
		component: () => import(/* webpackChunkName: "LoginLayout" */ '../views/Home.vue'),
	},
    {
		path: '/chat',
		name: 'Chat',
		component: () => import(/* webpackChunkName: "LoginLayout" */ '../views/Chat.vue'),
	},
	{
		path: '/chat/:chatId',
		name: 'ChatConversation',
		component: () => import(/* webpackChunkName: "LoginLayout" */ '../views/Conversation.vue'),
	},
    {
		path: '/home',
		name: 'MainPage',
		component: () => import(/* webpackChunkName: "LoginLayout" */ '../views/MainPage.vue')
	},
	{
		path: '/resetPassword',
		name: 'ResetPassword',
		component: () => import(/* webpackChunkName: "LoginLayout" */ '../views/ResetPassword.vue')
	}
]

const router = new VueRouter({
	mode: 'history',
	routes
})

export default router