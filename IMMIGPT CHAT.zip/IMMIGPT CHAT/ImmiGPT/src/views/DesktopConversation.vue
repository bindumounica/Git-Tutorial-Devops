<template>
    <div>
        <div class="NoDesktop chatMain">
            <div style="padding:12px;">
                <div v-if="messages.length == 0" class="flexCol alignCenter chatMain">
                    <v-icon size="200">mdi-message-text-outline</v-icon>
                    <span>No Messages</span>
                </div>
                <div style="overflow-y: scroll;">
                    <div v-if="messages.length > 0" :class="messages.length > 0 ? 'chat-container': 'displaynone'">
                        <div v-for="(val, index) in messages" :key="index" :class="[val.sender === userId ? 'message sent' : 'message received']">
                            <div class="message-content">{{ val.message}}</div>
                            <!-- <b>{{ val.sender }}</b>: <em>{{ val.message }}</em> -->
                        </div>
                    </div>
                </div>
                <div>
                    <v-text-field hide-details placeholder="Send a message" v-model="text" append-icon="mdi-send" dense solo flat outlined rounded @keyup.enter="sendMessage()"></v-text-field>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios'
import Profile from '../components/Profile.vue'
export default {
    name: "App",
    components: {
        Profile
    },
    props : ['chatId'],
    data: () => ({
        text : '',
        chatlist : [],
        userId: '',
        receipentId : '',
        messages: [],
        socket: null
    }),
    created() {
    // Create the WebSocket instance
        this.userId = this.$cookies.get('email');
        this.receipentId = this.$props.chatId;
        console.log('this.userId', this.userId);
        console.log('this.receipentId', this.receipentId)
        this.socket = new WebSocket(`ws://localhost:3000?sender=${this.userId}&reciever=${this.receipentId}`);

        // Define a WebSocket 'onmessage' event handler to receive messages from the server
        this.socket.onmessage = (event) => {
            console.log('event', event.data.toString('utf8'))
            const message = JSON.parse(event.data);
            console.log('message', message)
            // Check if the message is intended for the current user
            if (message.recipient === this.userId || message.sender === this.userId) {
                this.messages.push(message);
            }
        };
    },
    mounted(){
        console.log('checking', this.$props.chatId)
        this.receipentId = this.$props.chatId;
        this.userId = this.$cookies.get('email');
        console.log('this.userId', this.userId)
        if (this.userId) {
            console.log('this.userId', this.userId)
            // this.socket.send(JSON.stringify({ event: 'join', userId: this.userId }));
        }
        axios.get(`https://0p0uuuryfi.execute-api.us-west-2.amazonaws.com/dev/messages?sender=${this.userId}&recipient=${this.receipentId}`)
        .then(response => {
            this.messages = response.data;
        })
        .error(error=>{
            console.log('error in loading messages',error);
        })
    },
    beforeDestroy() {
    },
    methods: {
        openProfile(){
            this.drawer = true;
        },
        // sendMessage(msg){
        //     let mitem = {
        //         'id' : 10,
        //         'sender': 'Me',
        //         'text': msg
        //     }
        //     this.messageText = '';
        //     this.messages.push(mitem);
        //     let mitem2 = {
        //         'id' : 10,
        //         'sender': 'Rec',
        //         'text': 'Recieved to me , I will reply later'
        //     }
        //     this.messages.push(mitem2);
        // },

        sendMessage() {
            const messageData = {
                sender: this.userId,
                recipient: this.receipentId,
                message: this.text
            };
            // Send the message data to the server using WebSockets
            console.log("sendMessage", JSON.stringify(messageData))
            axios.post('https://0p0uuuryfi.execute-api.us-west-2.amazonaws.com/dev/messages', messageData)
            .then(sent => {
                this.socket.send(JSON.stringify(messageData));
                // Add the message data to the messages array
                this.messages.push(messageData);
                this.text = null;
            })
            .error(error => {
                console.log('error in sending message',error);
                this.text = null;
            })
            // Clear the text input
        }
    }
}
</script>
<style>
@media screen and (max-width: 767px) {
    .chatMain{
        height: 100vh;
    }
    .NoMobile{
        display: none;
    }
    .message-list {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    }

    .message {
    display: flex;
    flex-direction: column;
    max-width: 70%;
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 8px;
    word-wrap: break-word;
    }

    .message-content {
    word-wrap: break-word;
    text-align: left;
    }

    .sent {
    align-self: flex-end !important;
    background-color: #0B4374;
    color: #FFF;
    }

    .received {
    align-self: flex-start !important;
    background-color: #f0f2f5;
    color: #000;
    }
    .chat-container {
        display: flex;
        flex-direction: column;
        height: 77vh;
        /* align-items: center; */
        justify-content: flex-end;
        overflow-y: scroll; 
    }
}
@media screen and (min-width: 768px) {
    /* .NoDesktop{
        display: none;
    } */
    .chatMain{
        height: calc(100vh - 120px);
    }
    .message-list {
        flex: 1;
        overflow-y: auto;
        padding: 10px;
    }
    .message {
    display: flex;
    flex-direction: column;
    max-width: 70%;
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 8px;
    word-wrap: break-word;
    }

    .message-content {
    word-wrap: break-word;
    text-align: left;
    }

    .sent {
    align-self: flex-end !important;
    background-color: #0B4374;
    color: #FFF;
    }

    .received {
    align-self: flex-start !important;
    background-color: #f0f2f5;
    color: #000;
    }
    .chat-container {
        display: flex;
        flex-direction: column;
        height: calc(100vh - 120px);
        /* align-items: center; */
        justify-content: flex-end;
        overflow-y: scroll; 
    }
}

.flexCol{
    display: flex;
    flex-direction: column;
}
.alignCenter{
    justify-content: center;
    align-items: center;
}
.displaynone{
    display: none;
}
</style>