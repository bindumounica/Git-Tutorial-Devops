<template>
    <div>
        <div class="NoDesktop chatMain">
            <div>
                <div @click="openProfile()" style="display: flex;flex-direction: row;justify-content: flex-start;align-items: center;padding: 6px 16px;background-color: #f0f2f5;cursor: pointer;">
                    <v-avatar style="margin-right: 12px;" size="40" color="#d0d5dd">
                        <v-icon color="#FFF" size="40">mdi-account-circle</v-icon>
                    </v-avatar>
                    <span style="color: #000;">{{ userName }}</span>
                </div>
            </div>
            <div style="padding:12px;">
                <div v-if="messages.length == 0" class="flexCol alignCenter chatMain">
                    <v-icon size="200">mdi-message-text-outline</v-icon>
                    <span>No Messages</span>
                </div>
                <div style="overflow-y: scroll;">
                    <div v-if="messages.length > 0" :class="messages.length > 0 ? 'chat-container': 'displaynone'">
                        <div v-for="(val, index) in messages" :key="index" :class="[val.sender === userId ? 'message sent' : 'message received']">
                            <div class="message-content">{{ val.message}}</div>
                            <!-- <b>{{ val.sender }}</b>: <em>{{ val.message }}</em> -->
                        </div>
                    </div>
                </div>
                <div>
                    <v-text-field hide-details placeholder="Send a message" v-model="text" append-icon="mdi-send" dense solo flat outlined rounded @keyup.enter="sendMessage()"></v-text-field>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
import Profile from '../components/Profile.vue'
export default {
    name: "App",
    components: {
        Profile
    },
    data: () => ({
        text : '',
        chatlist : [],
        userId: '',
        receipentId : '',
        messages: [],
        socket: null,
        userName : ''
    }),
    created() {
    // Create the WebSocket instance
        this.userId = this.$cookies.get('email');
        this.receipentId = this.$route.params.chatId.split('-')[0];
        console.log('this.userId', this.userId);
        console.log('this.receipentId', this.receipentId)
        this.socket = new WebSocket(`ws://localhost:3000?sender=${this.userId}&reciever=${this.receipentId}`);

        // Define a WebSocket 'onmessage' event handler to receive messages from the server
        this.socket.onmessage = (event) => {
            console.log('event', event.data.toString('utf8'))
            const message = JSON.parse(event.data);
            console.log('message', message)
            // Check if the message is intended for the current user
            if (message.recipient === this.userId || message.sender === this.userId) {
                this.messages.push(message);
            }
        };
    },
    mounted(){
        console.log('checkingdetails', this.$route.params.chatId);
        let details =this.$route.params.chatId.split('-');
        this.receipentId = details[0];
        this.userName = details[1];
        this.userId = this.$cookies.get('email');
        console.log('this.userId', this.userId)
        console.log('this.receipentId', this.receipentId)
        if (this.userId) {
            console.log('this.userId', this.userId)
            // this.socket.send(JSON.stringify({ event: 'join', userId: this.userId }));
        }
    },
    beforeDestroy() {
    },
    methods: {
        openProfile(){
            this.drawer = true;
        },
        // sendMessage(msg){
        //     let mitem = {
        //         'id' : 10,
        //         'sender': 'Me',
        //         'text': msg
        //     }
        //     this.messageText = '';
        //     this.messages.push(mitem);
        //     let mitem2 = {
        //         'id' : 10,
        //         'sender': 'Rec',
        //         'text': 'Recieved to me , I will reply later'
        //     }
        //     this.messages.push(mitem2);
        // },

        sendMessage() {
            const messageData = {
                sender: this.userId,
                recipient: this.receipentId,
                message: this.text
            };
            // Send the message data to the server using WebSockets
            console.log("sendMessage", JSON.stringify(messageData))
            this.socket.send(JSON.stringify(messageData));
            // Add the message data to the messages array
            this.messages.push(messageData);
            // Clear the text input
            this.text = null;
        }
    }
}
</script>
<style>
@media screen and (max-width: 767px) {
    .chatMain{
        height: calc(100vh - 120px);
    }
    .NoMobile{
        display: none;
    }
    .message-list {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    }

    .message {
    display: flex;
    flex-direction: column;
    max-width: 70%;
    margin-bottom: 10px;
    padding: 8px;
    border-radius: 8px;
    word-wrap: break-word;
    }

    .message-content {
    word-wrap: break-word;
    text-align: left;
    }

    .sent {
    align-self: flex-end !important;
    background-color: #0B4374;
    color: #FFF;
    }

    .received {
    align-self: flex-start !important;
    background-color: #f0f2f5;
    color: #000;
    }
    .chat-container {
        display: flex;
        flex-direction: column;
        height: calc(100vh - 120px);
        /* align-items: center; */
        justify-content: flex-end;
        overflow-y: scroll; 
    }
}
@media screen and (min-width: 768px) {
    .NoDesktop{
        display: none;
    }
}

.flexCol{
    display: flex;
    flex-direction: column;
}
.alignCenter{
    justify-content: center;
    align-items: center;
}
.displaynone{
    display: none;
}
</style>