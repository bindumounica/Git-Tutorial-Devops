<template>
    <div class="center">
        <div ref="textContainer" id="scrollContainer" class="chatContent" v-on:scroll="handleScroll">
            <h2>
                ImmiGPT
            </h2>
            <div>
                <div v-if="questionAnswers.length == 0" class="cardContent">
                    <div class="cursor singleCard">
                        <div class="activeQuestion">
                            <v-icon color="#0b4374" style="margin-right: 4px;">mdi-send</v-icon>
                            <span @click="clickOnCard('What are the regular questions asked in H1B Visa Interview ?')">
                                What are the regular questions asked in H1B Visa Interview ?
                            </span>
                        </div>
                        <div class="activeQuestion">
                            <v-icon color="#0b4374" style="margin-right: 4px;">mdi-send</v-icon>
                            <span @click="clickOnCard('What are the regular questions asked in F1 Visa Interview ?')">
                                What are the regular questions asked in F1 Visa Interview ?
                            </span>
                        </div>
                        <div class="activeQuestion">
                            <v-icon color="#0b4374" style="margin-right: 4px;">mdi-send</v-icon>
                            <span @click="clickOnCard('What are the requirements for B1/B2 Visa ?')">
                                What are the requirements for B1/B2 Visa ?
                            </span>
                        </div>
                    </div>

                </div>
            </div>
            <div v-if="renderTextFlag" class="textRender" v-for="questionAnswer, index in questionAnswers" :key="index">
                <div class="textRender2">
                    <div style="display: flex;flex-direction: row ;justify-content: flex-start;margin-bottom: 16px;">
                        <v-avatar v-if="picture" size="30"
                            style="margin-right: 8px;display: flex;align-items: flex-start;justify-content: flex-start;">
                            <img :src=picture />
                        </v-avatar>
                        <v-avatar color="#0b4374" v-else size="30" style="margin-right: 8px;">
                            <span style="color:#FFF">{{ name.substring(0, 1) }}</span>
                        </v-avatar>
                        <p style="text-align: left;white-space: pre-line;color: #000;margin: 0;"><b>{{
                            questionAnswer.question }}</b></p>
                    </div>
                    <div v-if="questionAnswer.answer">
                        <div class="copylikedislike">
                            <div style="display: flex;flex-direction: row ;justify-content: flex-start;">
                                <v-avatar size="30"
                                    style="margin-right: 8px;display: flex;align-items: flex-start;justify-content: flex-start;">
                                    <img src="../assets/logoImmiGpt.jpg" />
                                </v-avatar>
                                <p style="text-align: left;white-space: pre-line;color: #000;">{{ questionAnswer.answer }}
                                </p>
                            </div>
                            <div :key="refresh" class="copylikedislikeInner">
                                <div>
                                    <v-icon v-if="!questionAnswer.nocopy" size="18" class="copyIcon"
                                        @click="copyToClipboard(questionAnswer.answer, index)">
                                        mdi-content-copy
                                    </v-icon>
                                    <v-icon v-else size="18" class="copyIcon">
                                        mdi-check
                                    </v-icon>
                                </div>
                                <v-icon size="18" class="copyIcon" @click="thumbsAction('up')">
                                    mdi-thumb-up-outline
                                </v-icon>
                                <v-icon size="18" class="copyIcon" @click="thumbsAction('down')">
                                    mdi-thumb-down-outline
                                </v-icon>
                            </div>
                        </div>
                        <v-divider color="lightgrey"></v-divider>
                    </div>
                    <div v-else>
                        <BlinkingLoader v-if="blinkingloader && !questionAnswer.answer" />
                        <div v-else-if="timeOutFlag"
                            style="display: flex;flex-direction: row;justify-content: flex-start;align-items: center;">
                            <span
                                style="padding : 8px 12px; border: 1px red solid;border-radius: 8px;font-size: medium;color: red;">Server
                                under maintenance, please try again</span>
                        </div>
                        <div v-else style="display: flex;flex-direction: row ;justify-content: flex-start;">
                            <v-avatar size="30"
                                style="margin-right: 8px;display: flex;align-items: flex-start;justify-content: flex-start;">
                                <img src="../assets/logoImmiGpt.jpg" />
                            </v-avatar>
                            <p :key="refresh" style="text-align: left;white-space: pre-line;color: #000;">{{ renderedText }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="messageSender">
                <div class="messageSenderWidth">
                    <div v-if="renderedText != '' && questionAnswers.length > 0">
                        <v-btn solo flat outlined
                            style="text-transform: capitalize;padding: 4px;margin-bottom:12px;border-color: #0B4374;"
                            @click="manageGenarator()">
                            <v-icon size="15"
                                v-if="renderedText !== '' && !answerRendered">mdi-checkbox-blank-outline</v-icon>
                            <v-icon v-else>mdi-sync</v-icon>
                            <span v-if="renderedText !== '' && !answerRendered">
                                Stop generating
                            </span>
                            <span v-else>
                                Regenerate response
                            </span>
                        </v-btn>
                    </div>
                    <div
                        style="display: flex;flex-direction: row;justify-content: center; align-items: center;width: 100%;margin:0px 0px 16px 16px;">
                        <div class="textareaCustom" style="width: 100%;">
                            <v-textarea hide-details background-color="#FFF" v-model="searchText"
                                placeholder="Send a message" auto-grow dense no-resize rows="1" :autofocus=true
                                class="icon-color custom-textarea" block outlined elevation="0"
                                @keydown.enter.exact.prevent="renderTextTemp">
                                ></v-textarea>
                        </div>
                        <div>
                            <v-icon
                                :disabled="blinkingloader || (questionAnswers.length > 0 && questionAnswers[questionAnswers.length - 1] && !questionAnswers[questionAnswers.length - 1].answer)"
                                style="transform: translateX(-32px);" color="#0b4374"
                                @click="renderTextTemp">mdi-send</v-icon>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <template>
            <div class="text-center">
                <v-dialog overlay-opacity="0.9" v-model="dialog" width="80%">
                    <v-card>
                        <v-card-title class="text-h6 grey lighten-2">
                            <div
                                style="display: flex;flex-direction: row;align-items: center;justify-content: space-between;width: 100%;">
                                <div>
                                    <v-avatar color="#FFF" style="margin-right: 8px;">
                                        <v-icon>
                                            {{ feedbackIcon }}
                                        </v-icon>
                                    </v-avatar>
                                    <span>Provide feedback</span>
                                </div>
                                <div>
                                    <v-avatar @click="dialog = false">
                                        <v-icon>mdi-close</v-icon>
                                    </v-avatar>
                                </div>
                            </div>
                        </v-card-title>

                        <v-textarea hide-details outlined name="input-7-4" placeholder="Enter your feedback"
                            class="vtextarea-margin"></v-textarea>

                        <v-divider></v-divider>

                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="#0B4374" @click="dialog = false">
                                <span style="text-transform: capitalize;color: #FFF;">Submit Feedback</span>
                            </v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </div>
        </template>
    </div>
</template>

<script>
import BlinkingLoader from '../components/BlinkingLoader.vue';
import axios from 'axios';
export default {
    components: { BlinkingLoader },
    data: () => ({
        searchText: '',
        renderTextFlag: false,
        text: "Hello, World!",
        question: '',
        renderedText: "",
        refresh: 1,
        index: 0,
        blinkingloader: false,
        timeOutFlag: false,
        questionAnswers: [],
        questions: [],
        answerRendered: false,
        stop: false,
        sessionId: '',
        textFieldRowsCount: 1,
        refresh: 1,
        rows: 1,
        maxRows: 5,
        picture: '',
        name: '',
        dialog: false,
        feedbackIcon: '',
        scrollAutoFlag: true
    }),
    mounted() {
        this.picture = this.$cookies.get('picture')
        this.name = this.$cookies.get('name')
        this.token = this.$cookies.get('token')
        if (!this.token) {
            this.$router.push({
                name: 'Home'
            }).catch(error => {
                console.log('error', error)
            })
        }
        console.log('this.rendered', this.renderedText)
        let headers = {
            Authorization: 'Bearer ' + this.token
        }
        let gauth = this.$cookies.get('gauth');
        if (gauth) {
            headers['Google-Auth'] = 'True'
        }
        console.log('headers', headers)
        axios.get('https://backend.immigpt.net/session/getUserSessionsList?length=100', { headers: headers })
            .then((response) => {
                console.log('response', response.data?.userId)
                this.$cookies.set('userId', response.data?.userId)

                // this.questions = [
                //     {
                //         "userId": 1,
                //         "sessionId": "285b8ead647d22638a6549c30bcd4aae0691b777dafecf4199e2640546e82b38",
                //         "firstQuestion": "What is the validity period for a h1b visa",
                //         "startTime": "2023-05-01 10:23:34.0",
                //         "endTime": "2023-05-01 10:40:00.0"
                //     },
                //     {
                //         "userId": 1,
                //         "sessionId": "3u429u34023y42834u239u203i8293947234823492342",
                //         "firstQuestion": "What is H1b",
                //         "startTime": "2023-05-02 11:12:34.0",
                //         "endTime": "2023-05-02 11:50:00.0"
                //     }
                // ]
                let testdata = {
                    "today": [],
                    "yesterday": [
                        {
                            "userId": 69,
                            "sessionId": "c17b6cd522a6cc4e5284263352e57e0065b39627d7ebdfe6a736571d7ee8f199",
                            "firstQuestion": "hello man this is sai gopaTouch and hold a clip to pin it. Unpinned clips will be deleted after 1 hour.",
                            "startTime": "2023-07-10 23:17:39.0",
                            "endTime": "2023-07-10 23:18:24.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "07eb229c69b69e20a4b7df34d23d9d73eb2d9b701f333245d27517caf6ff773b",
                            "firstQuestion": "how is visa",
                            "startTime": "2023-07-10 01:03:12.0",
                            "endTime": "2023-07-10 01:03:28.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "f5eacc9fb7d47a59ea70816cdb775a42bc0c877559a2182ed3b0e8c21feeac88",
                            "firstQuestion": "hey",
                            "startTime": "2023-07-10 01:03:12.0",
                            "endTime": "2023-07-10 01:04:00.0"
                        }
                    ],
                    "lastWeek": [
                        {
                            "userId": 69,
                            "sessionId": "2ddacae0209af3ccbb119cbed9ee4dd137211c3f1a386642dadf37568455baf5",
                            "firstQuestion": "What is H1b",
                            "startTime": "2023-07-08 10:20:34.0",
                            "endTime": "2023-07-08 19:30:32.0"
                        }
                    ],
                    "thisMonth": [],
                    "lastMonth": [
                        {
                            "userId": 69,
                            "sessionId": "20bd8605cd93e32ca06aeeca9e36bfbf57e491e849ae91d623922b76a4a913e6",
                            "firstQuestion": "zhjsusisisisios",
                            "startTime": "2023-06-24 01:04:05.0",
                            "endTime": "2023-07-09 23:21:47.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "4502db2797d7c7c995d18f184ffb8393273bb62bf803c8337502164f96287ad8",
                            "firstQuestion": "hello",
                            "startTime": "2023-06-24 01:03:58.0",
                            "endTime": "2023-07-09 23:02:03.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "59e242f2da90a27ce5dca63f907c5f8a11b8c2663d41750d1522ff6c8c923e13",
                            "firstQuestion": "king",
                            "startTime": "2023-06-24 01:03:05.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "be23e3c355566afd100c984f2f193fcaca422335cf44e3ab793811fc06900278",
                            "firstQuestion": "hello",
                            "startTime": "2023-06-24 01:02:54.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "41ea591605f2c913a7929751838959a4e2f905144eb3b1c7b8a46f23208a6922",
                            "firstQuestion": "bz",
                            "startTime": "2023-06-24 01:01:57.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "1f1cff7f48db7008dd78dc2b69c87b858ca2cd18f85aca9dddc0a4d6b36edc8b",
                            "firstQuestion": "gu",
                            "startTime": "2023-06-24 01:00:54.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "181c7cb3cc171905ca27a9c8214e5850f50db4c463a86a813dd63bdbc25c2ff3",
                            "firstQuestion": "hi",
                            "startTime": "2023-06-24 00:59:27.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "24a7b2c0a8c57a45f55c08be1c416a02f65e3706baefbb571b15a206ffe42eac",
                            "firstQuestion": "ji",
                            "startTime": "2023-06-24 00:46:21.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "62fbf3c0d3336c2208a379e71b65dda1146afd10bc402c2cfd1173b4efb6a99e",
                            "firstQuestion": "hello",
                            "startTime": "2023-06-24 00:43:47.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "e4f395eb2bdfb932792cc1bc4405d858148ff6829568c09aa54c866252eec2ab",
                            "firstQuestion": "hekskssbsj",
                            "startTime": "2023-06-24 00:30:47.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "4650f45c601abc16fff6d9475eeb5e9181fc4d06febab710a5054ac96e5a4304",
                            "firstQuestion": "hi",
                            "startTime": "2023-06-24 00:29:11.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "f2463005a3213a0ebbb85a291b8dd5037cb16cb43c8f2910d5ddeb04aece6a49",
                            "firstQuestion": "herer",
                            "startTime": "2023-06-24 00:20:23.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "2724595a329e58e5ec8ebd2dcaf1e5d4f72bd9cf64c7cdfa8155ecf5678a5791",
                            "firstQuestion": "hello",
                            "startTime": "2023-06-24 00:20:13.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "821869743e24772817df285310f96bf8b0ae667a285a531737620ef46902b37a",
                            "firstQuestion": "bshs",
                            "startTime": "2023-06-24 00:20:05.0",
                            "endTime": "2023-06-25 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "9e5c34a277f98b7b19018d4be2589dde6d8aa984aae834a6b1b1b567ea145056",
                            "firstQuestion": "hi",
                            "startTime": "2023-06-22 21:37:59.0",
                            "endTime": "2023-06-23 00:00:00.0"
                        },
                        {
                            "userId": 69,
                            "sessionId": "d8bba2e0d0d7a6cfb63a749298fdc2d276056b5fc8b57fd9b42ddb1a66b65067",
                            "firstQuestion": "hi",
                            "startTime": "2023-06-22 21:20:58.0",
                            "endTime": "2023-06-23 00:00:00.0"
                        }
                    ],
                    "previous": []
                }
                this.questions = response.data;
                console.log('this.questions', this.questions)
                this.$emit('getQuestions', this.questions);
                const cookies = document.cookie.split(';');
                const myCookie = cookies.find(cookie => cookie.trim().startsWith('sessionId='));
                const myValue = myCookie ? myCookie.split('=')[1] : null;
                console.log('document.cookie', myValue)
                this.sessionId = myValue;
                if (this.sessionId != null && this.sessionId != 'null') {
                    this.renderSession(this.sessionId)
                }
            })
            .catch((error) => {
                console.log('error', error)
                if (error?.response?.status == 401) {
                    this.$cookies.remove('token');
                    this.$cookies.remove('name')
                    this.$cookies.remove('email')
                    this.$cookies.remove('picture');
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    this.$router.push({
                        name: 'Home'
                    })
                        .catch(error => {
                            console.log('error', error)
                        })
                }
            })
        // document.cookie = 'sessionId=285b8ead647d22638a6549c30bcd4aae0691b777dafecf4199e2640546e82b38; expires=0; path=/';
    },
    methods: {
        async copyToClipboard(mytext, index) {
            try {
                console.log('index', index)
                await navigator.clipboard.writeText(mytext);
                this.questionAnswers[index].nocopy = true;
                console.log('this.questionAnswers[index].nocopy', this.questionAnswers[index].nocopy)
                this.refresh += 1;
                setTimeout(() => {
                    this.questionAnswers[index].nocopy = undefined;
                    console.log('this.questionAnswers[index].nocopy', this.questionAnswers[index].nocopy);
                    this.refresh += 1;
                }, 3000);
            } catch ($e) {
                alert('Cannot copy');
            }
        },
        thumbsAction(feedback) {
            this.dialog = true;
            if (feedback == 'up') {
                this.feedbackIcon = 'mdi-thumb-up-outline'
            } else {
                this.feedbackIcon = 'mdi-thumb-down-outline'
            }
        },
        clickOnCard(text) {
            this.question = text;
            this.searchText = text;
            this.renderTextTemp();
        },
        renderSession(sessionId) {
            let headers = {
                Authorization: 'Bearer ' + this.token
            }
            console.log('headers', headers)
            let gauth = this.$cookies.get('gauth');
            if (gauth) {
                headers['Google-Auth'] = 'True'
            }
            axios.get('https://backend.immigpt.net/session/getUserSession?sessionId=' + sessionId, { headers: headers })
                .then((response) => {
                    console.log('response', response)
                    let jsonContent = response.data.session;
                    let questions = [];
                    for (let key in jsonContent) {
                        questions.push({ question: key, answer: jsonContent[key] });
                    }
                    this.questionAnswers = questions;
                    this.renderTextFlag = true;
                    console.log('finally', this.questionAnswers)
                })
                .catch((error) => {
                    console.log('error', error);
                    if (error?.response?.status == 401) {
                        this.$cookies.remove('token');
                        this.$cookies.remove('name')
                        this.$cookies.remove('email')
                        this.$cookies.remove('picture');
                        document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                        this.$router.push({
                            name: 'Home'
                        })
                    }
                })
        },
        createNewChat() {
            this.questionAnswers = [];
            document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            this.sessionId = null;
        },
        manageGenarator() {
            if (this.renderedText !== '' && !this.answerRendered) {
                this.stop = true;
                if (this.questionAnswers[this.questionAnswers.length - 1]) {
                    this.answerRendered = true;
                    this.questionAnswers[this.questionAnswers.length - 1].answer = this.renderedText;
                }
            }
            else {
                this.refresh = 0
                this.index = 0
                this.blinkingloader = false
                this.answerRendered = false
                this.renderedText = ""
                this.stop = false;
                if (this.questionAnswers[this.questionAnswers.length - 1]) {
                    this.questionAnswers[this.questionAnswers.length - 1].answer = ""
                }
                this.renderText();
            }
        },
        clearAllQuestions() {
            this.questions = [];
            this.questionAnswers = [];
            let headers = {
                Authorization: 'Bearer ' + this.token
            }
            console.log('headers', headers)
            let gauth = this.$cookies.get('gauth');
            if (gauth) {
                headers['Google-Auth'] = 'True'
            }
            axios.delete('https://backend.immigpt.net/deleteUserSessions', { headers: headers })
                .then((response) => {
                    console.log('response', response)
                    document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                    this.sessionId = null;
                })
                .catch((error) => {
                    console.log('error', error)
                    if (error?.response?.status == 401) {
                        this.$cookies.remove('token');
                        this.$cookies.remove('name')
                        this.$cookies.remove('email')
                        this.$cookies.remove('picture');
                        document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                        this.$router.push({
                            name: 'Home'
                        })
                    }
                })
        },
        renderTextTemp() {
            if (this.searchText == '') return;
            if (this.blinkingloader || (this.questionAnswers.length > 0 && this.questionAnswers[this.questionAnswers.length - 1] && !this.questionAnswers[this.questionAnswers.length - 1].answer)) {
                return;
            }
            this.renderedText = '',
                this.rows = 1;
            this.index = 0,
                this.renderTextFlag = true;
            this.stop = false;
            // this.$emit('getQuestions', this.questions)
            let questionandanswer = {
                question: this.searchText,
                answer: ''
            }
            this.questionAnswers.push(questionandanswer);
            this.blinkingloader = true;
            let questionasked = this.searchText;
            this.searchText = '';
            // let gauth = this.$cookies.get('gauth');
            // if (gauth) {
            //     headers['Google-Auth'] = 'True'
            // }
            axios.post('https://api.immigpt.net/chat?query=' + questionasked)
                .then(async (response) => {
                    // this.renderTextFlag = true;
                    console.log('response', response.data.response)
                    let headers = {
                        Authorization: 'Bearer ' + this.token
                    }
                    console.log('headers', headers);
                    let params = {
                        "email": this.$cookies.get('email'),
                        "startTime": Date.now(),
                        "endTime": Date.now(),
                        "qnA": {
                            [questionasked]: response.data.response,
                        }
                    }
                    console.log('headers', JSON.stringify(params.qnA));
                    let queryParams = {};
                    if (this.sessionId) {
                        queryParams.sessionId = this.sessionId
                    }
                    let gauth = this.$cookies.get('gauth');
                    if (gauth) {
                        headers['Google-Auth'] = 'True'
                    }
                    axios.post('https://backend.immigpt.net/session/saveUserSession', params, { headers: headers, params: queryParams })
                        .then((response) => {
                            console.log('question saved', response)
                            console.log('checking sessionId', this.sessionId)
                            if (!this.sessionId || this.sessionId == null || this.sessionId == 'null') {
                                let storeSession = `sessionId=${response.data.sessionId}; expires=0; path=/`
                                console.log('storeSession', storeSession)
                                document.cookie = storeSession;
                                this.sessionId = response.data.sessionId;
                                this.questions.today.unshift({ firstQuestion: questionasked, sessionId: this.sessionId })
                                this.$emit('getQuestions', this.questions)
                            }
                        })
                        .catch((error) => {
                            console.log('error', error)
                        })
                    // this.searchText = '';
                    this.refresh = 0
                    this.index = 0
                    this.text = response.data.response;
                    this.blinkingloader = false
                    this.answerRendered = false
                    console.log('this.text check', this.text)
                    this.renderText();
                })
                .catch((error) => {
                    console.log('error', error)
                    if (error?.response?.status == 401) {
                        this.$cookies.remove('token');
                        this.$cookies.remove('name')
                        this.$cookies.remove('email')
                        this.$cookies.remove('picture');
                        document.cookie = "sessionId=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
                        this.$router.push({
                            name: 'Home'
                        })
                    }
                    setTimeout(() => {
                        console.log('This message will be displayed after 3 seconds.');
                        this.blinkingloader = false;
                        this.timeOutFlag = true;
                    }, 30000);
                })
        },
        handleScroll() {
            const container = this.$refs.textContainer
            const isAtBottom = container.scrollTop + 10 + container.clientHeight >= container.scrollHeight;
            console.log(container.scrollTop, container.clientHeight, container.scrollHeight)
            isAtBottom ? this.scrollAutoFlag = true : this.scrollAutoFlag = false
        },
        renderText() {
            // console.log('textmk', this.text.length)
            this.refresh += 1;
            // console.log("check", this.renderedText)
            if (this.stop) return;
            if (this.index < this.text.length) {
                this.renderedText += this.text.charAt(this.index);
                this.index += 1;
                // console.log('before time', this.renderedText)
                let d = Date.now()
                // console.log("date", d)
                setTimeout(this.renderText, 10);
            }
            else {
                if (this.questionAnswers[this.questionAnswers.length - 1]) {
                    this.questionAnswers[this.questionAnswers.length - 1].answer = this.renderedText
                    this.answerRendered = true;
                }
            }
        },
    },
    updated() {
        console.log('this.handleScroll()',this.scrollAutoFlag)
        if(this.scrollAutoFlag) {
            this.$nextTick(() => {
                this.$refs.textContainer.scrollTo({
                    top: this.$refs.textContainer.scrollHeight,
                    // behavior: 'smooth'
                });
            })
        }
        // console.log('#####################', this.$refs.textContainer.scrollHeight)
    }
}
</script>

<style scoped>
@media screen and (min-width: 768px) {
    .center {
        display: flex;
        flex-direction: row;
        background-image: linear-gradient(rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.95)), url('../assets/logoImmiGpt.jpg');
        width: 100%;
        height: 100vh !important;
        /* background-size: contain; */
        background-repeat: no-repeat;
        background-position: center center;
    }

    .cardContent {
        width: 100%;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
    }

    .singleCard {
        width: 100%;
        height: 20vh;
        display: flex;
        flex-direction: column;
        justify-content: space-around;
        align-items: flex-start;
        padding: 8px 16px;
        text-align: left;
        border: 2px #0B4374 solid;
        border-radius: 12px;
        cursor: pointer;
        font-weight: 600;
    }

    .chatContent {
        display: flex;
        flex-direction: column;
        align-items: center;
        /* margin: 2% 0%; */
        width: 100%;
        height: 85vh;
        overflow-y: scroll;
        padding: 32px 16px 0px 16px;
    }

    .sideBarSpace {
        width: 20%;
    }

    .textRender {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        padding: 0% 1.5%;
    }

    .textRender2 {
        width: 85%;
        margin: 16px 0%;
    }

    .messageSender {
        position: fixed;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 80%;
    }

    .messageSenderWidth {
        width: 80%;
    }

    .copylikedislike {
        display: flex;
        flex-direction: row;
        align-items: flex-start;
        justify-content: space-between;
    }

    .copylikedislikeInner {
        display: flex;
        flex-direction: row;
        align-items: flex-start;
    }

    .copyIcon {
        margin: 4px;
        cursor: pointer;
    }

    .vtextarea-margin {
        margin: 24px;
    }
}

@media screen and (max-width:767px) {
    .center {
        display: flex;
        flex-direction: column;
        background-image: linear-gradient(rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.95)), url('../assets/logoImmiGpt.jpg');
        width: 100%;
        height: calc(100vh- 68px) !important;
        /* background-size: contain; */
        background-repeat: no-repeat;
        background-position: center center;
    }

    .cardContent {
        width: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .singleCard {

        width: 80%;
        height: 30vh;
        display: flex;
        flex-direction: row;
        justify-content: flex-start;
        align-items: center;
        flex-wrap: wrap;
        padding: 8px 16px;
        text-align: left;
        border: 2px #0B4374 solid;
        border-radius: 12px;
        margin-bottom: 10%;
        font-weight: 400;
    }

    .chatContent {
        display: flex;
        flex-direction: column;
        align-items: center;
        margin: 2% 0%;
        width: 100%;
        height: 78vh;
        overflow-y: scroll;
    }

    .sideBarSpace {
        width: 100%;
    }

    .textRender {
        display: flex;
        justify-content: flex-start;
        align-items: center;
        width: 95%;
        padding: 0% 1.5%;
    }

    .textRender2 {
        width: 100%;
        margin: 16px 0%;
    }

    .messageSender {
        position: fixed;
        bottom: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%
    }

    .messageSenderWidth {
        width: 90%;
    }

    .copylikedislike {
        display: flex;
        flex-direction: column;
        /* align-items: flex-end; */
        justify-content: space-between;
    }

    .copylikedislikeInner {
        display: flex;
        flex-direction: row;
        /* align-items: flex-end; */
        justify-content: flex-end;
    }

    .copyIcon {
        margin: 0px 4px 8px 4px;
        cursor: pointer;
    }

    .vtextarea-margin {
        margin: 12px;
    }
}

.cursor {
    cursor: pointer;
    ;
}

.activeQuestion:hover {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;
    padding: 4px 12px;
    border-radius: 8px;
    background-color: lightgray;
}

.activeQuestion {
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    align-items: center;
    padding: 4px 12px;
}
</style>
<style scoped>
.v-text-field--outlined>>>fieldset {
    border-color: #0B4374;
    border-width: 2px;
}
</style>
<style>
.icon-color .v-icon {
    color: blue;
}

.v-textarea textarea {
    max-height: 140px;
    overflow-y: auto;
}

/* width */
::-webkit-scrollbar {
    width: 6px;
}

/* Track */
::-webkit-scrollbar-track {
    box-shadow: inset 0 0 5px #FFF;
    border-radius: 10px;
}

/* Handle */
::-webkit-scrollbar-thumb {
    background: #0b4374;
    border-radius: 10px;
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
    background: #0b4374;
}
</style>
<style>
.v-application--is-ltr .v-textarea.v-text-field--enclosed .v-text-field__slot textarea {
    padding-right: 36px !important;
}</style>