<template>
    <div class="center">
        <div class="columnCenter">
            <!-- <div
            style="margin:4%"
            >
                <img style="width:120px; height: 120px;" src="../assets/logogpt.jpeg"/>    
            </div> -->
            <span v-if="!loginActive && !signUpActive" style="font-size:larger;"><b>Welcome to ImmiGPT</b></span>
            <span v-if="!loginActive && !signUpActive" style="font-size:larger;"><b>Login to continue</b></span>
            <span v-if="loginActive || signUpActive" style="font-size:larger;font-weight: 550;">Welcome!</span>
            <div v-if="!loginActive && !signUpActive" style="width:100%; margin: 4%;">
                <div class="rowCenter">
                    <v-btn
                    solo
                    flat
                    elevation="0"
                    color=#0B4374
                    style="text-transform: capitalize;color: #FFF;"
                    @click="loginAction()"
                    >
                        Log in
                    </v-btn>
                    <v-btn
                    solo
                    flat
                    elevation="0"
                    color=#0B4374
                    style="text-transform: capitalize;color: #FFF;"
                    @click="signUpAction()"
                    >
                        Sign up
                    </v-btn>
                </div>
            </div>
            <div v-if="loginActive && !signUpActive" style="width:100%; margin: 4%;">
                <!-- <p style="text-align: left;margin: 0;">Enter Email Address</p> -->
                <v-text-field
                    v-model="email1"
                    @change="Testing"
                    dense
                    flat
                    outlined
                    hide-details="auto"
                    :rules = 'validateEmail'
                    label="Email Address"
                    append-icon="mdi-arrow-right-bold"
                    color=#0B4374
                    style="background-color: #FFF;margin-bottom: 24px;"
                    @click:append="continueForLogin()"
                    @keyup.enter="continueForLogin()"
                ></v-text-field>
                <!-- <p style="text-align: left;margin: 0;">Enter Password</p> -->
                <v-text-field
                    v-show="password1show"
                    @change="Testing"
                    dense
                    flat
                    outlined
                    v-model="password1"
                    :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
                    :rules="[rules.required, rules.min]"
                    :type="show1 ? 'text' : 'password'"
                    name="input-10-1"
                    label="Password"
                    hint="At least 8 characters"
                    counter
                    style="background-color: #FFF;margin-bottom: 24px;"
                    @keyup.enter="continueForLogin()"
                    @click:append="show1 = !show1"
                ></v-text-field>
                <span :key="refresh" v-if="unauthorized" style="color: red;">{{ unauthorizedMessage }}</span>
                <v-btn
                :loading="continueLoader"
                solo
                dense
                flat
                elevation="0"
                block
                style="text-transform: capitalize;color:#FFF"
                color=#0B4374
                @click="continueForLogin()"
                >
                    {{ loginButtonName }}
                </v-btn>
                <p style="text-align: left;font-size:14px;display: flex;flex-direction: row;justify-content: center;align-items: center;">Don't have an account? <a @click="signUpText()">Sign Up with Google</a></p>
                <p style="text-align: left;font-size:14px;display: flex;flex-direction: row;justify-content: center;align-items: center;"><a @click="forgotPassword()">Forgot password?</a></p>
                <p style="margin: 16px;">or</p>
                <!-- <v-btn
                    class="ma-2"
                    outlined
                    color="#0B4374"
                    background-color="#FFF"
                    style="text-transform: capitalize;background-color: #FFF;"
                    >
                    <v-icon size="30">mdi-google</v-icon>
                    Continue with Google
                </v-btn> -->
            </div>
            <div v-if="!loginActive && signUpActive" style="width:100%; margin: 4%;">
                <!-- <p style="text-align: left;font-size:14px;">Your number will only be used to verify your identity for security purposes.</p> -->
                <!-- <p style="text-align: left;margin: 0;">Enter Email Address</p> -->
                <v-text-field
                    v-model="email2"
                    @change="failed = false"
                    dense
                    flat
                    outlined
                    hide-details="auto"
                    :rules = "validateEmail"
                    label="Email Address"
                    append-icon="mdi-arrow-right-bold"
                    color=#0B4374
                    style="background-color: #FFF;margin-bottom: 24px;border-color:#0B4374;"
                    @click:append="continueForSignUp()"
                    @keyup.enter="continueForSignUp()"
                ></v-text-field>
                <!-- <p style="text-align: left;margin: 0;">Enter Password</p> -->
                <v-text-field
                    v-show="usernameshow"
                    v-model="username"
                    dense
                    flat
                    outlined
                    hide-details="auto"
                    label="User name"
                    color=#0B4374
                    style="background-color: #FFF;margin-bottom: 24px;border-color:#0B4374;"
                    append-icon="mdi-account"
                    @click:append="continueForSignUp()"
                    @keyup.enter="continueForSignUp()"
                ></v-text-field>
                <v-text-field
                    v-show="password2show"
                    dense
                    flat
                    outlined
                    v-model="password2"
                    :append-icon="show2 ? 'mdi-eye' : 'mdi-eye-off'"
                    :rules="[rules.required, rules.min]"
                    :type="show2 ? 'text' : 'password'"
                    name="input-10-1"
                    hint="At least 8 characters"
                    label="Password"
                    counter
                    @click:append="show2 = !show2"
                    @keyup.enter="continueForSignUp()"
                    style="background-color: #FFF;margin-bottom: 24px;border-color:#0B4374;"
                ></v-text-field>
                <span v-if="failed" style="color: red;">{{ failedMessage }}</span>
                <v-btn
                :loading="continueLoader"
                solo
                dense
                flat
                elevation="0"
                block
                style="text-transform: capitalize;color:#FFF"
                color=#0B4374
                @click="continueForSignUp()"
                >
                    {{ signUpButton }}
                </v-btn>
                <p style="text-align: left;font-size:14px; display: flex;flex-direction: row;justify-content: center;align-items: center;">Already have an account? <span style="color:#0B4374"><a @click="loginText()">Log in</a></span></p>
                <p style="margin: 16px;">or</p>
                <!-- <v-btn
                    class="ma-2"
                    outlined
                    color="#0B4374"
                    id="googleSignInButton"
                    style="text-transform: capitalize;background-color: #FFF;"
                    >
                    <v-icon size="30">mdi-google</v-icon>
                    Continue with Google
                </v-btn> -->
            </div>
            <div style="display:flex; justify-content:center; margin-top: 10px;" id="buttonDiv"></div>
        </div>
    </div>
</template>
<script src="https://accounts.google.com/gsi/client" async defer></script>
<script>
import axios from 'axios';
import {Buffer} from 'buffer';
export default {
    data: () =>({
        loginActive: false,
        signUpActive: false,
        email1 : '',
        email2 : '',
        password1 : '',
        password1show: false,
        password2show : false,
        usernameshow: false,
        password2 : '',
        username: '',
        show1: false,
        show2: false,
        token: '',
        refresh : 0,
        loginButtonName : 'Continue',
        signUpButton: 'Continue',
        failedMessage: 'Failed in signup',
        unauthorized: false,
        unauthorizedMessage: 'Invalid username or password',
        failed:false,
        loggedInMessage : 'Logged in successfully',
        validateEmail: [ 
                    v => !!v || 'Email is required',
                    v => (/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/.test(v)) || 'Enter valid Email'
                    ],
        rules: {
          required: value => !!value || 'Required.',
          min: v => v.length >= 8 || 'Min 8 characters'
        },
        continueLoader: false
    }),
    mounted(){
        console.log("In mounted now")
        this.token = this.$cookies.get('token')
        console.log('check' , this.token)
        if (this.token) {    
            this.routeToChat();
        }
        else {
            google.accounts.id.initialize({
              client_id: "885560999939-uv51l6cgtbt9t7063r7bahmf74hem9e3.apps.googleusercontent.com",
              callback: data => this.handleCredentialResponse(data),
              scope: 'email profile'
            });
            google.accounts.id.renderButton(
              document.getElementById("buttonDiv"),
              { theme: "filled_blue", size: "large"}  // customization attributes
            );
            google.accounts.id.prompt(); // also display the One Tap dialog
        }
    },
    computed: {
        Testing(){
            this.unauthorized = false; this.refresh += 1; console.log('refreshing', this.email1, this.password1);
        },
    },
    methods : {
        routeToChat(){
            this.$router.push({
                name : 'MainPage',
                params: { data: 'login' }
            })
            .catch(error => {
                console.log('error', error)
            })
        },
        hideEmailDetails(email){
            if(email && !(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/.test(email))){
                return false
            }
            return true
        },
        forgotPassword(){
            this.$router.push({
                name : 'ResetPassword'
            })
        },
        handleCredentialResponse(response) {
            console.log("Encoded JWT ID token: " + JSON.stringify(response));
            this.token = response.credential;
            console.log('this.token', this.token)
            this.$cookies.set('token', this.token)
            let payload= this.parseJwt(this.token);
            this.$cookies.set('name', payload.name)
            this.$cookies.set('email', payload.email)
            this.$cookies.set('picture', payload.picture)
            this.$cookies.set('userId', payload.userId)
            this.$cookies.set('gauth', true)
            let params = {
                "email" : payload.email,
                "username" : payload.email,
                "password" : ''
            }
            // let gauth = this.$cookies.get('gauth');
            // if (gauth) {
            //     headers['Google-Auth'] = 'True'
            // }
            axios.post('https://backend.immigpt.net/signup?isGoogleSignIn=true', params)
            .then((response)=>{
                this.continueLoader = false;
                console.log('response', response)
                // this.$cookies.set('token', response.data.token)
                if (this.token) {
                    this.$router.push({
                        name : 'MainPage',
                        params: { data: 'login' }
                    })
                    .catch(error => {
                        console.log('error', error)
                    })
                }
            })  
            .catch((error)=>{
                this.continueLoader = false;
                console.log('Error ', error);
                if (error.response.data == 'Email is already taken!') {
                    this.failedMessage = 'Email already registered'
                }
                this.failed = true;
            })
        },
        parseJwt(token) {
            var base64Payload = token.split('.')[1];
            // var payload = Buffer.from(base64Payload, 'base64');
            // return JSON.parse(payload.toString());
            var payload = JSON.parse(atob(base64Payload));
            return payload;
        },
        loginAction(){
            this.loginActive = true;
        },
        signUpAction(){
            this.signUpActive = true;
        },
        signUpText(){
            this.signUpActive = true;
            this.loginActive = false;
        },
        loginText(){
            this.signUpActive = false;
            this.loginActive = true;
        },
        continueForLogin(){
            console.log('email1', this.email1)
            console.log('password1', this.password1)
            if (this.email1 && !this.password1) {
                if (!(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/.test(this.email1))) {
                    this.unauthorized = true;
                    this.unauthorizedMessage = 'Enter Valid Email Address'
                    return;
                }
                if (this.loginButtonName == 'Login') {
                    this.unauthorized = true;
                    this.unauthorizedMessage = 'Enter valid password'
                    return;
                }
                this.loginButtonName = 'Login';
                this.password1show = true;
                return;
            }
            if (!this.email1 || this.email1 == '') {
                this.unauthorized = true;
                this.unauthorizedMessage = 'Enter Valid Email Address'
                return;
            }
            if (!this.password1 || this.password1 == '') {
                this.unauthorized = true;
                this.unauthorizedMessage = 'Enter valid password'
                return;
            }
            if (this.email1 && this.password1) {
                if (!(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/.test(this.email1))) {
                    this.unauthorized = true;
                    this.unauthorizedMessage = 'Enter Valid Email Address'
                    return;
                }
                if (this.password1.length <= 7) {
                    this.unauthorized = true;
                    this.unauthorizedMessage = 'Enter valid password'
                    return;
                }
                this.continueLoader = true;
                let params = {
                    "email" : this.email1,
                    "password" : this.password1
                }
                // let gauth = this.$cookies.get('gauth');
                // if (gauth) {
                //     headers['Google-Auth'] = 'True'
                // }
                axios.post('https://backend.immigpt.net/login', params)
                .then((response)=>{
                    this.continueLoader = false;
                    console.log('response', response)
                    this.token = response.data.token;
                    this.$cookies.set('token', this.token);
                    let payload= this.parseJwt(this.token);
                    this.$cookies.set('name', payload.username)
                    this.$cookies.set('email', payload.email)
                    this.$cookies.set('userId', payload.userId)
                    // this.$cookies.set('picture', payload.picture)
                    if(this.token) {
                        this.$router.push({
                            name : 'MainPage',
                            params: { data: 'login' },
                        })
                        .catch(error => {
                            console.log('error', error)
                        })
                    }
                })  
                .catch((error)=>{
                    this.continueLoader = false;
                    console.log('Error @@@@@@@@@@@@@@@@@', error);
                    if(error?.response?.status == 401){
                        this.unauthorized = true;
                        this.email1 = '',
                        this.password1 = ''
                    }
                })
            }
        },
        continueForSignUp(){
            this.failedMessage = '';
            this.failed = false;
            if (this.signUpButton == 'Sign Up') {
                if (!this.email2 || !this.username || !this.password2) {
                    this.failed = true;
                    this.failedMessage = (!this.email2) ? 'Email is mandatary' : (!this.username) ? 'User name is mandatary' : (!this.password2) ? 'Password is mandatary' : '';
                    return;
                }
                else if (this.email2 && this.username && this.password2) {
                    if (!(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/.test(this.email2))) {
                        this.failed = true;
                        this.failedMessage = 'Invalid Email'
                        return;
                    }
                    else if (this.password2.length < 8) {
                        this.failed = true;
                        this.failedMessage = 'Invalid password'
                        return;
                    } else {
                        this.continueLoader = true;
                        let params = {
                            "email" : this.email2,
                            "username" : this.username,
                            "password" : this.password2
                        }
                        // let gauth = this.$cookies.get('gauth');
                        // if (gauth) {
                        //     headers['Google-Auth'] = 'True'
                        // }
                        axios.post('https://backend.immigpt.net/signup', params)
                        .then((response)=>{
                            this.continueLoader = false;
                            console.log('response', response)
                            this.token = response.data.token;
                            this.$cookies.set('token', this.token);
                            let payload= this.parseJwt(this.token);
                            this.$cookies.set('name', payload.username)
                            this.$cookies.set('email', payload.email)
                            if (this.token) {
                                this.$router.push({
                                    name : 'MainPage',
                                    params: { data: 'signup' },
                                })
                                .catch(error => {
                                    console.log('error', error)
                                })
                            }
                        })  
                        .catch((error)=>{
                            this.continueLoader = false;
                            console.log('Error ', error);
                            if (error.response.data == 'Email is already taken!') {
                                this.failedMessage = 'Email already registered'
                            }
                            this.failed = true;
                        })
                    }
                }
            } else {
                if (this.email2 && !this.username && !this.password2) {
                    if (!(/^[a-z0-9]+@[a-z]+\.[a-z]{2,3}$/.test(this.email2))) {
                        return;
                    }
                    this.usernameshow = true
                    return;
                }
                if (this.email2 && this.username && !this.password2) {
                    this.password2show = true;
                    this.signUpButton = 'Sign Up'
                    return;
                }
            }
        }
    }
}
</script>
<style scoped>

@media screen and (max-width:766px) {
    .columnCenter {
    display: flex;
    flex-direction: column;
    align-items:center;
    margin-top: 80%;
    width: 75%;
}
.center{
    display: flex;
    justify-content: center;
    align-items: center;
    background-image: linear-gradient(rgba(255,255,255,0.7), rgba(255,255,255,0.5)), url('../assets/mobileImmiGpt.jpg');
    width:100%;
    height:100vh;
    background-size: cover;
    background-repeat: no-repeat;
    background-position:center center;
}
}

@media screen and (min-width:768px) {
    .columnCenter {
    display: flex;
    flex-direction: column;
    align-items:center;
    width: 20%;
}
.center{
    display: flex;
    justify-content: center;
    align-items: center;
    background-image: linear-gradient(rgba(255,255,255,0.9), rgba(255,255,255,0.6)), url('../assets/desktopImmiGpt.jpg');
    width:100%;
    height:100vh;
    background-size: cover;
    background-repeat: no-repeat;
    background-position:center center;
}
}


.rowCenter{
    display: flex;
    flex-direction: row;
    justify-content: space-around;
}
</style>

<style>
.v-icon.v-icon {
    font-size: 24px;
}
</style>
<style scoped>
.v-text-field--outlined >>> fieldset {
  border-color:#0B4374;
  border-width: 2px;
}
</style>
