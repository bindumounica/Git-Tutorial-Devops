<template>
    <div style="display:flex; flex-direction: row;">
        <div class="center">
            <div v-if = "openSidebarFlag" class="sideBarSpace">
                <v-menu transition="slide-x-transition">
                    <template v-slot:activator="{ on, attrs }">
                        <SideBar 
                            :questions="questions"
                            @clearQuestions = "clearQuestions" 
                            @newChat="createNewChat()" 
                            @openMenuItem="openMenuItem" 
                            @renderSession="renderSession" 
                            @getChatMessages="getChatMessages"
                            @closeSideBar="CloseSidebarAction">
                        </SideBar>
                    </template>
                </v-menu>
            </div>
            <div v-else style="position: relative;">
                <div @click="openSidebarAction()" style="position: fixed;top: 12px;left: 12px; display: flex;border: 1px #000 solid;padding: 10px;border-radius: 8px;cursor: pointer;">
                    <svg stroke="currentColor" fill="none" stroke-width="2" viewBox="0 0 24 24" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4" height="1.2em" width="1.2em" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="9" y1="3" x2="9" y2="21"></line></svg>
                </div>
            </div>
            <div style="width:100%" :key="refresh">
                <!-- <TopTabBar /> -->
                <Chat v-if="activegpt" ref="childComponent" @getQuestions = "getQuestions" />
                <Profile v-else-if="activeProfile"/>
                <P2PChats v-else-if="activechats" ref="p2pChatDetails"/>
                <FAQ :questionAndAnswers="questionAndAnswers" v-else-if="activefaq || activeGetHelp"></FAQ>
                <Settings :key="refresh2" v-if="dialog"></Settings>
            </div>
        </div>
        <div >
            <v-snackbar
                :timeout="3000"
                :value="loginsuccess"
                absolute
                centered
                top
                right
                color="green accent-4"
                elevation="24"
                class="SlideMessage"
            >
                <div style="display: flex;flex-direction: row;align-items: center;justify-content: space-between;">
                    <span style="color:#FFF">{{ loggedInMessage }}</span>
                    <v-icon>mdi-close</v-icon>
                </div>
            </v-snackbar>
        </div>
    </div>
</template>

<script>
import TopTabBar from "../components/TopMenuBar.vue";
import SideBar from '../components/SideBar.vue'
import Chat from '../views/Chat.vue'
import Profile from '../components/Profile.vue'
import Settings from "../components/Settings.vue";
import axios from "axios";
import P2PChats from "../components/P2PChats.vue";
import FAQ from "../components/FAQ.vue";
export default {
    name: "App",
    components: {
        TopTabBar,
        SideBar,
        Chat,
        Profile,
        Settings,
        P2PChats,
        FAQ
    },
    data: () => ({
        openSidebarFlag: true,
        questions : [],
        token: '',
        activegpt: true,
		activechats: false,
		activeProfile:false,
		activeGetHelp:false,
        activefaq:false,
        activeSettings:false,
        dialog:false,
        refresh:1,
        refresh2:2,
        loginsuccess : false,
        loggedInMessage: 'Logged in successfully',
        questionAndAnswers: [
            {
            "question": "Can you explain the concept of artificial intelligence?",
            "answer": "Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think and learn like humans. It involves various subfields such as machine learning, natural language processing, computer vision, and more. AI enables machines to perform tasks that typically require human intelligence, such as recognizing patterns, making decisions, solving problems, and understanding and generating natural language. It has applications in various domains, including healthcare, finance, autonomous vehicles, virtual assistants, and more."
            },
            {
            "question": "What is the significance of renewable energy?",
            "answer": "Renewable energy refers to energy derived from sources that are naturally replenished, such as sunlight, wind, water, and geothermal heat. It is significant due to several reasons. Firstly, renewable energy sources are sustainable and do not deplete natural resources. They help reduce dependence on finite fossil fuel reserves, mitigating the environmental impacts associated with their extraction and combustion. Secondly, renewable energy plays a crucial role in combating climate change by reducing greenhouse gas emissions. It offers a cleaner and greener alternative to traditional energy sources, thereby helping to mitigate the harmful effects of carbon dioxide and other pollutants. Additionally, renewable energy promotes energy independence, enhances energy security, creates job opportunities, and fosters technological innovation."
            },
            {
            "question": "What is the theory of evolution?",
            "answer": "The theory of evolution, formulated by Charles Darwin, is a scientific explanation of how life on Earth has changed over time. It proposes that all species of organisms have descended from a common ancestor through a process called natural selection. According to this theory, variations exist within populations, and those individuals with advantageous traits that better suit their environment are more likely to survive and reproduce. Over successive generations, these beneficial traits become more prevalent in the population, leading to the emergence of new species. Evolution is driven by various factors, including genetic mutations, genetic drift, gene flow, and environmental pressures. The theory of evolution is a foundational concept in biology and provides a framework for understanding the diversity and interconnectedness of life."
            }
        ]

    }),
    mounted(){
        this.token = this.$cookies.get('token')
        if (!this.token) {    
            this.$router.push({
                name: 'Home'
            })
            .catch(error => {
                console.log('error', error)
            })
        }
        let loginmessage = this.$route.params.data;
        console.log('loginmessage', loginmessage , this.loginsuccess)
        if(loginmessage == 'login'){
            this.loggedInMessage = 'Logged in successfully'
            this.loginsuccess = true;
        } else if (loginmessage == 'signup') {
            this.loggedInMessage = 'Account created successfully';
            this.loginsuccess = true;
        }
    },
    methods : {
        openSidebarAction(){
            this.openSidebarFlag = true;
        },
        CloseSidebarAction(){
            this.openSidebarFlag = false;
        },
        createNewChat(){
            this.$refs.childComponent.createNewChat();
        },
        getChatMessages(chat){
            console.log('&&!checking', chat)
            this.$refs.p2pChatDetails.getChatMessages(chat);
        },
        renderSession(sessionId){
            console.log('called in Mainoage')
            this.$refs.childComponent.renderSession(sessionId);
        },
        getQuestions(questions){
            this.questions = questions
        },
        clearQuestions(){
            this.getQuestions([])
            this.$refs.childComponent.clearAllQuestions();
        },
        openMenuItem(item){
            console.log('@@@ ###', item == 'Settings')
            if (item == 'ImmiGPT') {
                this.dialog = false;
                this.activegpt= true,
                this.activechats= false,
                this.activeProfile = false,
                this.activeGetHelp = false
                this.activeSettings = false
                this.activefaq = false;
                this.refresh += 1;
            }
            else if (item == 'Chats') {
                this.dialog = false;
                this.activegpt= false,
                this.activechats= true,
                this.activeProfile = false,
                this.activeGetHelp = false;
                this.activefaq = false;
                this.activeSettings = false
                this.refresh += 1;
            }
            else if (item == 'Profile') {
                this.dialog = false;
                this.activegpt= false,
                this.activechats= false,
                this.activeProfile = true,
                this.activeGetHelp = false
                this.activefaq = false;
                this.activeSettings = false;
                console.log('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
                this.refresh += 1;
            }
            else if(item == 'Get Help!') {
                this.activegpt= false,
                this.activechats= false,
                this.activefaq = false;
                this.activeProfile = false,
                this.activeGetHelp = true;
                this.activeSettings = false
                this.dialog = false;
                this.refresh += 1;
            }
            else if(item == 'FAQs') {
                this.activegpt= false,
                this.activechats= false,
                this.activeProfile = false,
                this.activeGetHelp = false;
                this.activeSettings = false
                this.dialog = false;
                this.activefaq = true;
                console.log('reached last')
                this.refresh += 1;
            }
            else if (item == 'Settings') {
                this.dialog = true;
                console.log('@@@###################################')
                // this.activegpt= false,
                // this.activechats= false;
                this.activeSettings = true;
                // this.activeProfile = false,
                // this.activeGetHelp = false
                // this.activefaq = false;
                this.refresh2 += 1;
            }
            else{
                console.log('@@@in else', item)
            }
        }
    }
};
</script>

<style scoped>
@media screen and (min-width: 768px) {

    .center {
        display: flex;
        flex-direction: row;
        background-image: linear-gradient(rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.8)), url('../assets/desktopImmiGpt.jpg');
        width: 100%;
        height: calc(100vh - 48px);
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
    }

    .sideBarSpace {
        width: 30%;
    }
}

@media screen and (max-width:767px) {
    .center {
        display: flex;
        flex-direction: column;
        background-image: linear-gradient(rgba(255, 255, 255, 0.8), rgba(255, 255, 255, 0.8)), url('../assets/mobileImmiGpt.jpg');
        width: 100%;
        height: calc(100vh-68px);
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
    }

    .sideBarSpace {
        width: 100%;
    }
}

.SlideMessage{
    animation: slide-in 0.5s forwards;
}
@keyframes slide-in {
    0% {
        right: -400px;
    }

    100% {
        right: 20px;
    }
}
</style>