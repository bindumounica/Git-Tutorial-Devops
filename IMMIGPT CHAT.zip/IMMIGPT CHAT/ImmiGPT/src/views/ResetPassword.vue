<template>
    <v-app>
      <v-content>
        <v-container fluid>
          <v-layout style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
            <!-- Section 1: Forgot Password -->
            <div v-if="sent">
                <span style="color: orange;">{{ message }}</span>
            </div>
            <v-flex v-if="!token" xs12 sm6 class="widthSetUp">
              <h2 v-show="!showLoginButton">Forgot Password</h2>
              <v-text-field v-if="!token && !showLoginButton" outlined solot flat dense v-model="email" label="Email"></v-text-field>
              <v-btn color="#0B4374"  v-if="!token && !showLoginButton" @click="sendEmail"><span style="color: #FFF;">Send</span></v-btn>
              <v-btn v-else-if="showLoginButton" color="#0B4374" @click="login">
                  <span style="color: #FFF;">Login</span>
              </v-btn>
            </v-flex>
  
            <!-- Section 2: Reset Password -->
            <v-flex v-else xs12 sm6 class="widthSetUp">
              <h2>Reset Password</h2>
              <v-text-field outlined solot flat dense :rules="passwordRules" v-model="password" label="Password" type="password"></v-text-field>
              <v-text-field outlined solot flat dense :rules="getConfirmPasswordRules" v-model="confirmPassword" label="Confirm Password" type="password"></v-text-field>
              <v-btn color="#0B4374" :disabled="password != confirmPassword" @click="submitPassword"><span style="color: #FFF;">Change Password</span></v-btn>
            </v-flex>
          </v-layout>
        </v-container>
      </v-content>
    </v-app>
  </template>
  
  <script>
import axios from 'axios';

  export default {
    data() {
      return {
        email: '',
        password: '',
        confirmPassword: '',
        token: '',
        sent: false,
        passwordRules: [
            value => !!value || 'Password is required',
            value => value && value.length >= 8 || 'Password must be at least 8 characters',
        ],
        message: '',
        showLoginButton: false,
      };
    },
    mounted(){
        const urlParams = new URLSearchParams(window.location.search);
        this.token = urlParams.get('token');
        console.log(token);
    },
    computed: {
        getConfirmPasswordRules() {
        return [
            value => !!value || 'Confirm Password is required',
            value => value === this.password || 'Passwords do not match',
        ];
        },
    },
    watch(email){
        this.sent = false
    },
    methods: {
      sendEmail() {
        // Implement your logic for sending the email here
        console.log('Email:', this.email);
        // You can make an API request or perform other operations here
        axios.post('https://backend.immigpt.net/sendResetPasswordMail?email='+this.email)
        .then(response => {
            console.log('response', response)
            if (response?.status == 200) {
                this.sent = true;
                this.message = 'We have sent a reset password link to your mail. Please check'
                this.email = '';
                this.showLoginButton = true;
            }
        })
        .catch(error => {
            console.log('Error', error)
            this.$router.push({
                name: Home
            })
        })
      },
      submitPassword() {
        // Implement your logic for submitting the password here
        console.log('Password:', this.password);
        console.log('Confirm Password:', this.confirmPassword);
        // You can make an API request or perform other operations here
        axios.post('https://backend.immigpt.net/resetPassword?token='+this.token, { newPassword: this.password})
        .then(response => {
            console.log('response', response)
            this.sent = true;
            this.message = 'Password reset successfully, Redirecting to Login...'
            setTimeout(() => {
                this.$router.push({
                    name: 'Home'
                })
            }, 2000);
        })
        .catch(error => {
            console.log('error', error)
            if (error?.response?.status == 408) {
                this.sent = true;
                this.message = 'Your request for reset password has expired. Please try again.'
                this.password = '';
                this.confirmPassword = ''
                this.token = ''
            } else {
                this.$router.push({
                    name: Home
                })
            }
        })
      },
      login(){
        this.$router.push({
              name: 'Home' 
           });
      }
    },
  };
  </script>
  
  <style>
  /* Add your custom styles here */
  @media screen and (min-width: 768px) {
    .widthSetUp{
        width: 30%;
    }
  }
  @media screen and (max-width: 767px) {
    .widthSetUp{
        width: 85%;
    }
  }
  </style>
  